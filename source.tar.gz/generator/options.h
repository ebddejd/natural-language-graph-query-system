#ifndef OPTIONS_H
#define OPTIONS_H
#include <stdexcept>
#include <string>
#include <limits>

struct Options {
    int streets = 10;
    int segments = 5;
    int delay = 5;
    int coord = 20;
};

inline Options read_options(int argc, char** argv) {
    Options out;
    for (int i = 1; i < argc; ++i) {
        std::string flag = argv[i];
        if (flag != "-s" && flag != "-n" && flag != "-l" && flag != "-c")
            throw std::invalid_argument("unknown option: " + flag);
        if (++i == argc) throw std::invalid_argument("missing value for " + flag);
        std::size_t used = 0;
        long long number;
        try {
            number = std::stoll(argv[i], &used);
        } catch (const std::exception&) {
            throw std::invalid_argument("invalid value for " + flag);
        }
        if (used != std::string(argv[i]).size() ||
            number > std::numeric_limits<int>::max())
            throw std::invalid_argument("invalid value for " + flag);
        int minimum = flag == "-s" ? 2 : (flag == "-l" ? 5 : 1);
        if (number < minimum)
            throw std::invalid_argument(flag + " must be at least " + std::to_string(minimum) + ".");
        int value = static_cast<int>(number);
        if (flag == "-s") out.streets = value;
        if (flag == "-n") out.segments = value;
        if (flag == "-l") out.delay = value;
        if (flag == "-c") out.coord = value;
    }
    return out;
}
#endif
