#include "geometry.h"
#include "options.h"
#include <cerrno>
#include <cstdint>
#include <fcntl.h>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unistd.h>

class Random {
public:
    Random() : fd(open("/dev/urandom", O_RDONLY)) {
        if (fd < 0) throw std::runtime_error("cannot open /dev/urandom.");
    }
    ~Random() { close(fd); }
    Random(const Random&) = delete;
    Random& operator=(const Random&) = delete;

    int between(int low, int high) {
        std::uint64_t width = static_cast<std::int64_t>(high) - low + 1;
        const std::uint64_t full = std::uint64_t(1) << 32;
        const std::uint64_t limit = full - full % width;
        std::uint32_t value;
        do {
            std::size_t done = 0;
            while (done < sizeof(value)) {
                ssize_t n = read(fd, reinterpret_cast<char*>(&value) + done, sizeof(value) - done);
                if (n < 0 && errno == EINTR) continue;
                if (n <= 0) throw std::runtime_error("cannot read /dev/urandom.");
                done += static_cast<std::size_t>(n);
            }
        } while (value >= limit);
        return static_cast<int>(static_cast<std::int64_t>(low) +
                                static_cast<std::int64_t>(value % width));
    }
private:
    int fd;
};

std::string street_name(std::size_t number) {
    std::string name = "road ";
    do {
        name += static_cast<char>('a' + number % 26);
        number /= 26;
    } while (number);
    return name;
}

int main(int argc, char** argv) {
    try {
        Options opts = read_options(argc, argv);
        Random random;
        std::size_t old_count = 0;
        const int attempts = 25;
        while (true) {
            std::vector<std::vector<Point>> roads;
            int count = random.between(2, opts.streets);
            for (int i = 0; i < count; ++i) {
                std::vector<Point> road;
                road.push_back({random.between(-opts.coord, opts.coord),
                                random.between(-opts.coord, opts.coord)});
                int segments = random.between(1, opts.segments);
                for (int j = 0; j < segments; ++j) {
                    bool found = false;
                    for (int trial = 0; trial < attempts; ++trial) {
                        Point point{random.between(-opts.coord, opts.coord),
                                    random.between(-opts.coord, opts.coord)};
                        if (valid_extension(roads, road, point)) {
                            road.push_back(point);
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                        throw std::runtime_error("failed to generate valid input for 25 consecutive attempts.");
                }
                roads.push_back(road);
            }
            // Publish only after the whole new set has been generated successfully.
            for (std::size_t i = 0; i < old_count; ++i)
                std::cout << "rm \"" << street_name(i) << "\"\n";
            for (std::size_t i = 0; i < roads.size(); ++i) {
                std::cout << "add \"" << street_name(i) << "\"";
                for (Point point : roads[i])
                    std::cout << " (" << point.x << ',' << point.y << ')';
                std::cout << '\n';
            }
            std::cout << "gg" << std::endl;
            if (!std::cout) throw std::runtime_error("cannot write street commands.");
            break; // One snapshot per API request; original A3 is unchanged.
        }
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << std::endl;
        return 1;
    }
}
