#!/usr/bin/env python3
import sys
import re
from fractions import Fraction


class InputError(Exception):
    """A bad input line; the next line can still be processed."""


PAIR = re.compile(r'\s*\(\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*\)')


def read_cmd(row):
    """Return the command, lowercase road name, and list of points."""
    if row.strip() == "gg":
        return "gg", None, None

    hit = re.fullmatch(r'\s*(add|mod|rm)\s*"([^"\r\n]+)"([^\r\n]*)', row)
    if hit is None:
        raise InputError("invalid command.")

    cmd, name, tail = hit.groups()
    name = name.lower()  # Keep all spaces inside the name.
    if cmd == "rm":
        if tail.strip():
            raise InputError("rm takes only a street name.")
        return cmd, name, None

    dots = []
    pos = 0
    while tail[pos:].strip():
        hit = PAIR.match(tail, pos)
        if hit is None:
            raise InputError("invalid coordinate list.")
        dots.append((int(hit.group(1)), int(hit.group(2))))
        pos = hit.end()

    if len(dots) < 2:
        raise InputError("a street requires at least two coordinates.")
    if any(a == b for a, b in zip(dots, dots[1:])):
        raise InputError("a street cannot contain a zero-length segment.")
    return cmd, name, dots


def cross(u, v):
    """The 2D cross product of two direction vectors."""
    return u[0] * v[1] - u[1] * v[0]


def meet(a, b, c, d):
    """Find the intersection of segments a-b and c-d, or return None."""
    step_a = (b[0] - a[0], b[1] - a[1])
    step_b = (d[0] - c[0], d[1] - c[1])
    gap = (c[0] - a[0], c[1] - a[1])
    base = cross(step_a, step_b)

    if base == 0:
        # The updated specification excludes overlapping segments.
        # Collinear segments may still touch at a common endpoint.
        shared = {a, b} & {c, d}
        return next(iter(shared)) if len(shared) == 1 else None

    t = Fraction(cross(gap, step_b), base)
    u = Fraction(cross(gap, step_a), base)
    if 0 <= t <= 1 and 0 <= u <= 1:
        return a[0] + t * step_a[0], a[1] + t * step_a[1]
    return None


def make_graph(road_book):
    """Split intersecting segments into adjacent graph edges."""
    pieces = []
    for name, dots in road_book.items():
        for a, b in zip(dots, dots[1:]):
            pieces.append((name, a, b))

    pins = [set() for _ in pieces]  # Points collected on each segment.
    cuts = set()                  # Actual intersections between streets.
    for i, (name, a, b) in enumerate(pieces):
        for j in range(i + 1, len(pieces)):
            other, c, d = pieces[j]
            if name == other:
                continue
            spot = meet(a, b, c, d)
            if spot is not None:
                cuts.add(spot)
                pins[i].update((a, spot, b))
                pins[j].update((c, spot, d))

    dots = set()
    links = set()
    for group in pins:
        # On a straight segment, sorting by x then y gives its point order.
        row = sorted(group)
        dots.update(row)
        for a, b in zip(row, row[1:]):
            if a in cuts or b in cuts:
                links.add((a, b))

    dots = sorted(dots)
    tags = {spot: num for num, spot in enumerate(dots, start=1)}
    links = sorted((tags[a], tags[b]) for a, b in links)
    return dots, links


def show_graph(dots, links):
    """Send a complete graph to A2; flush even when stdout is a pipe."""
    edges = ",".join(f"<{a},{b}>" for a, b in links)
    sys.stdout.write(f"V {len(dots)}\nE {{{edges}}}\n")
    sys.stdout.flush()


def main():
    road_book = {}
    while True:
        line = sys.stdin.readline()
        if line == "":
            break
        try:
            cmd, name, dots = read_cmd(line.rstrip("\r\n"))
            if cmd == "gg":
                dots, links = make_graph(road_book)
                show_graph(dots, links)
                continue

            if cmd == "add":
                if name in road_book:
                    raise InputError("street currently exists.")
            elif name not in road_book:
                raise InputError("'mod' or 'rm' specified for a street that does not exist.")

            if cmd == "rm":
                del road_book[name]
            else:
                road_book[name] = dots
        except InputError as error:
            print(f"Error: {error}", file=sys.stderr)

    sys.exit(0)


if __name__ == "__main__":
    main()
