"""Retain exact street membership while using the copied A3 geometry code."""
import importlib.util,json,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('a1',Path(__file__).with_name('ece650-a1.py'))
a1=importlib.util.module_from_spec(spec);spec.loader.exec_module(a1)
def convert(text):
    roads={}
    for line in text.splitlines():
        cmd,name,points=a1.read_cmd(line)
        if cmd=='add':roads[name]=points
    return from_roads(roads)

def from_roads(roads):
    roads={name:[tuple(p) for p in points] for name,points in roads.items()}
    dots,edges=a1.make_graph(roads)
    def on(p,a,b):
        return a1.cross((p[0]-a[0],p[1]-a[1]),(b[0]-a[0],b[1]-a[1]))==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1])
    streets={name:[[u,v] for u,v in edges if any(on(dots[u-1],a,b) and on(dots[v-1],a,b) for a,b in zip(points,points[1:]))] for name,points in roads.items()}
    return {'nodes':len(dots),'edges':[list(e) for e in edges],'streets':streets,'geometry':{'coordinates':[[str(x),str(y)] for x,y in dots],'roads':{name:[list(p) for p in points] for name,points in roads.items()}}}
if __name__=='__main__':print(json.dumps(convert(sys.stdin.read())))
