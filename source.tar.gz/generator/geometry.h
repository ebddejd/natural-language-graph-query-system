#ifndef GEOMETRY_H
#define GEOMETRY_H
#include <algorithm>
#include <vector>

struct Point {
    int x, y;
    bool operator==(const Point& other) const { return x == other.x && y == other.y; }
};

// GCC and Clang support 128-bit integers; this avoids overflow for int coordinates.
inline __int128 turn(Point a, Point b, Point c) {
    return (static_cast<__int128>(b.x) - a.x) * (static_cast<__int128>(c.y) - a.y)
         - (static_cast<__int128>(b.y) - a.y) * (static_cast<__int128>(c.x) - a.x);
}

inline bool on_segment(Point a, Point b, Point p) {
    return turn(a, b, p) == 0 &&
        p.x >= std::min(a.x, b.x) && p.x <= std::max(a.x, b.x) &&
        p.y >= std::min(a.y, b.y) && p.y <= std::max(a.y, b.y);
}

inline bool overlaps(Point a, Point b, Point c, Point d) {
    if (turn(a, b, c) != 0 || turn(a, b, d) != 0) return false;
    // Strict inequality permits a single shared endpoint.
    if (a.x != b.x)
        return std::max(std::min(a.x, b.x), std::min(c.x, d.x)) <
               std::min(std::max(a.x, b.x), std::max(c.x, d.x));
    return std::max(std::min(a.y, b.y), std::min(c.y, d.y)) <
           std::min(std::max(a.y, b.y), std::max(c.y, d.y));
}

inline bool intersects(Point a, Point b, Point c, Point d) {
    auto p = turn(a, b, c), q = turn(a, b, d);
    auto r = turn(c, d, a), s = turn(c, d, b);
    if (on_segment(a, b, c) || on_segment(a, b, d) ||
        on_segment(c, d, a) || on_segment(c, d, b)) return true;
    return ((p < 0 && q > 0) || (p > 0 && q < 0)) &&
           ((r < 0 && s > 0) || (r > 0 && s < 0));
}

inline bool valid_extension(const std::vector<std::vector<Point>>& roads,
                            const std::vector<Point>& road, Point point) {
    Point start = road.back();
    if (start == point) return false;
    for (const auto& other : roads)
        for (std::size_t i = 1; i < other.size(); ++i)
            if (overlaps(start, point, other[i-1], other[i])) return false;
    for (std::size_t i = 1; i < road.size(); ++i) {
        if (overlaps(start, point, road[i-1], road[i])) return false;
        // Consecutive segments must share their endpoint. Other self-intersections
        // are avoided so each generated street is a simple polyline.
        if (i + 1 < road.size() && intersects(start, point, road[i-1], road[i]))
            return false;
    }
    return true;
}
#endif
