"""Map-first navigation: explicit coordinates, place selection, real route variants."""
import copy, json, math, secrets, threading, time
from core import Error
from walking import inside, distance
from planner import completion

def points(route):
    g=route['geometry'];return [p for line in g['coordinates'] for p in line] if g['type']=='MultiLineString' else g['coordinates']
def edges(route):
    ps=[tuple(round(v,5) for v in p) for p in points(route)]
    return {tuple(sorted((a,b))) for a,b in zip(ps,ps[1:]) if a!=b}
def distinct(route,others):
    a=edges(route)
    return bool(a) and all(len(a & edges(b))/max(1,min(len(a),len(edges(b))))<.90 for b in others)
SCHEMA={'type':'object','properties':{k:{'type':['string','null']} for k in ('origin','destination','question')},'required':['origin','destination','question'],'additionalProperties':False}
def intent(text,state):
    message,_=completion([{'role':'system','content':'Extract explicit origin and destination changes for Waterloo Ontario route planning using the travel mode selected in the UI. Always respond in English. Null means unchanged. Translate Chinese names to English search terms. No coffee stops, live traffic, accessibility guarantees or custom avoidance in this version; ask a clarification for unsupported constraints, never silently drop them. If school is ambiguous ask which school. Never invent coordinates. Current confirmed endpoints and last question (data): '+json.dumps({k:state.get(k) for k in ('origin','destination','question','mode')},ensure_ascii=False)}, {'role':'user','content':text}],[{'type':'function','function':{'name':'set_endpoints','description':'Extract endpoints or ask clarification','parameters':SCHEMA}}])
    try:
        calls=message['tool_calls'];assert len(calls)==1 and calls[0]['function']['name']=='set_endpoints'
        result=json.loads(calls[0]['function']['arguments']);assert set(result)=={'origin','destination','question'}
        for v in result.values():assert v is None or isinstance(v,str) and 0<len(v)<=300
        return result
    except (AssertionError,KeyError,ValueError,TypeError):raise Error('Could not interpret the request. Please use the origin and destination fields.',502)
class NavigationSession:
    def __init__(self,provider):self.provider=provider;self.lock=threading.Lock();self.state={};self.revision=0
    def public(self,message=None):
        return dict(revision=self.revision,mode=self.state.get('mode','walk'),message=message or self.state.get('message','Choose a starting point on the map, then a destination, or search by name.'),**{k:self.state.get(k) for k in ('origin','destination','pending','routes','selected','trace')})
    def handle(self,b,reserve=lambda:None):
        if not self.lock.acquire(False):raise Error('A route request is already running. Please wait.',409)
        try:
            if b.get('revision')!=self.revision:raise Error('Page state changed. Please refresh and retry.',409)
            old=copy.deepcopy(self.state)
            try:self.action(b,reserve)
            except Exception:self.state=old;raise
            self.revision+=1;return self.public()
        finally:self.lock.release()
    def invalidate(self):
        for k in ('routes','selected','pending','trace'):self.state.pop(k,None)
    def action(self,b,reserve):
        s=self.state;a=b.get('action')
        if a in ('point','search','swap'):s.pop('next_search',None)
        if a=='mode':
            if b.get('mode') not in ('walk','drive','transit'):raise Error('Unsupported travel mode')
            s['mode']=b['mode'];self.invalidate();self.plan();return
        if a=='reset':self.state={};return
        if a=='select':
            if b.get('id') not in [r['id'] for r in s.get('routes',[])]:raise Error('This route has expired. Please plan again.')
            s['selected']=b['id'];return
        if a=='swap':
            s['origin'],s['destination']=s.get('destination'),s.get('origin');self.invalidate();self.plan();return
        if a=='point':
            field=b.get('field');lon=b.get('lon');lat=b.get('lat')
            if field not in ('origin','destination') or type(lon) not in (int,float) or type(lat) not in (int,float) or not inside(lon,lat):raise Error('Please choose a point within the supported Waterloo area.')
            self.invalidate();s[field]={'id':secrets.token_hex(6),'name':('Current location ' if b.get('current_location') is True else 'Map pin ')+f'{lat:.5f}, {lon:.5f}','lon':lon,'lat':lat};self.plan();return
        if a=='search':
            field=b.get('field');text=b.get('text')
            if field not in ('origin','destination') or not isinstance(text,str) or not 1<=len(text)<=300:raise Error('Enter a valid place name.')
            self.invalidate();s.pop(field,None);self.search(field,text);return
        if a=='choose':
            pending=s.get('pending') or {};choice=next((p for p in pending.get('options',[]) if p['id']==b.get('id')),None)
            if not choice:raise Error('Select a place from the results.')
            s[pending['field']]=choice;s.pop('pending',None)
            if s.get('next_search'):
                field,text=s.pop('next_search');self.search(field,text)
            else:self.plan()
            return
        if a=='message':
            text=b.get('text')
            if not isinstance(text,str) or not 1<=len(text)<=2000:raise Error('Enter your route request.')
            reserve();r=intent(text,s)
            if r['question']:s['question']=r['question'];s['message']=r['question'];return
            self.invalidate();s.pop('next_search',None);s.pop('question',None)
            searches=[(f,r[f]) for f in ('origin','destination') if r[f]]
            for f,_ in searches:s.pop(f,None)
            if len(searches)>1:s['next_search']=searches[1]
            if searches:self.search(*searches[0])
            else:self.plan()
            return
        if a=='plan':self.plan();return
        raise Error('Unsupported action')
    def search(self,field,text):
        options=self.provider.geocode(text)
        for i,p in enumerate(options):p['id']=p['id'] or str(i)
        self.state['pending']={'field':field,'options':options};self.state['message']='Please confirm the '+('origin' if field=='origin' else 'destination')+'.' if options else 'No place found. Try another name or select a point on the map.'
    def plan(self):
        s=self.state;s.pop('pending',None)
        if not s.get('origin') or not s.get('destination'):
            s['message']='Please set the '+('origin' if not s.get('origin') else 'destination')+'.';return
        a,b=s['origin'],s['destination']
        if distance((a['lon'],a['lat']),(b['lon'],b['lat']))<10:raise Error('Choose endpoints at least 10 metres apart.')
        started=time.monotonic();mode=s.get('mode','walk')
        try:base=self.provider.route([a,b],mode=mode)
        except Error as exc:
            if mode!='transit':raise
            s['routes']=[];s['selected']=None;s['trace']=[]
            s['message']='Public transit routing is unavailable for these endpoints. Try different stops or check current services in Google Maps. '+str(exc)
            return
        routes=[base];trace=[{'strategy':'short','mode':mode,'distance_m':base['distance_m']}]
        if base['distance_m']>15000:raise Error('This preview supports routes up to 15 km.',422)
        ps=points(base);partial=False
        attempts=[] if mode=='transit' else [('balanced',None),('short',ps[len(ps)//2]),('short',ps[len(ps)//3])]
        for kind,avoid in attempts:
            if len(routes)>=3:break
            if time.monotonic()-started>32:partial=True;break
            try:r=self.provider.route([a,b],route_type=kind,avoid=avoid,mode=mode)
            except Error:partial=True;continue
            accepted=r['distance_m']<=min(15000,base['distance_m']*1.8+150) and distinct(r,routes)
            trace.append({'strategy':kind if not avoid else 'avoid_midroute_location','distance_m':r['distance_m'],'distinct_accepted':accepted})
            if accepted:routes.append(r)
        routes.sort(key=lambda r:r['distance_m'])
        for i,r in enumerate(routes):r.update(id=secrets.token_hex(8),color=['#2563eb','#e07b16','#8b46cf'][i],recommended=i==0)
        s['routes']=routes;s['selected']=routes[0]['id'];s['trace']=trace
        s['message']=f'{len(routes)} distinct route(s) found. The shortest available option is recommended. '+('Some alternatives could not be checked. ' if partial else '')+('No duplicate routes are shown.' if len(routes)==1 else 'Select a route or card to compare.')
        if mode=='transit':
            if not base.get('has_transit'):
                s['message']='The transit provider returned a walking-only option, not a confirmed bus or rail itinerary. Use the Google Maps link to check current transit services.'
                for r in routes:r['walking_only']=True
            else:s['message']+=' Transit coverage depends on provider data; live departures and service disruptions are not verified.'
