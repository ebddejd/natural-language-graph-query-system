"""Map-first navigation: explicit coordinates, place selection, real route variants."""
import copy, json, math, secrets, threading, time
from core import Error
from walking import inside, distance
from planner import completion

def points(route):
    g=route['geometry'];return [p for line in g['coordinates'] for p in line] if g['type']=='MultiLineString' else g['coordinates']
def edges(route):
    ps=[tuple(round(v,5) for v in p) for p in points(route)]
    return {tuple(sorted((a,b))) for a,b in zip(ps,ps[1:]) if a!=b}
def distinct(route,others):
    a=edges(route)
    return bool(a) and all(len(a & edges(b))/max(1,min(len(a),len(edges(b))))<.90 for b in others)
SCHEMA={'type':'object','properties':{k:{'type':['string','null']} for k in ('origin','destination','question')},'required':['origin','destination','question'],'additionalProperties':False}
def intent(text,state):
    message,_=completion([{'role':'system','content':'Extract explicit origin and destination changes for Waterloo Ontario WALKING route planning. Null means unchanged. Translate Chinese names to English search terms. No coffee stops, driving, traffic, accessibility guarantees or custom avoidance in this version; ask a clarification for unsupported constraints, never silently drop them. If school is ambiguous ask which school. Never invent coordinates. Current confirmed endpoints and last question (data): '+json.dumps({k:state.get(k) for k in ('origin','destination','question')},ensure_ascii=False)}, {'role':'user','content':text}],[{'type':'function','function':{'name':'set_endpoints','description':'Extract endpoints or ask clarification','parameters':SCHEMA}}])
    try:
        calls=message['tool_calls'];assert len(calls)==1 and calls[0]['function']['name']=='set_endpoints'
        result=json.loads(calls[0]['function']['arguments']);assert set(result)=={'origin','destination','question'}
        for v in result.values():assert v is None or isinstance(v,str) and 0<len(v)<=300
        return result
    except (AssertionError,KeyError,ValueError,TypeError):raise Error('需求解析失败，请直接使用起点和终点输入框',502)
class NavigationSession:
    def __init__(self,provider):self.provider=provider;self.lock=threading.Lock();self.state={};self.revision=0
    def public(self,message=None):
        return dict(revision=self.revision,message=message or self.state.get('message','点击地图选起点，再选终点；也可以输入地点名称。'),**{k:self.state.get(k) for k in ('origin','destination','pending','routes','selected','trace')})
    def handle(self,b,reserve=lambda:None):
        if not self.lock.acquire(False):raise Error('正在规划，请稍候',409)
        try:
            if b.get('revision')!=self.revision:raise Error('页面状态已变化，请刷新后重试',409)
            old=copy.deepcopy(self.state)
            try:self.action(b,reserve)
            except Exception:self.state=old;raise
            self.revision+=1;return self.public()
        finally:self.lock.release()
    def invalidate(self):
        for k in ('routes','selected','pending','trace'):self.state.pop(k,None)
    def action(self,b,reserve):
        s=self.state;a=b.get('action')
        if a in ('point','search','swap'):s.pop('next_search',None)
        if a=='reset':self.state={};return
        if a=='select':
            if b.get('id') not in [r['id'] for r in s.get('routes',[])]:raise Error('路线已过期，请重新规划')
            s['selected']=b['id'];return
        if a=='swap':
            s['origin'],s['destination']=s.get('destination'),s.get('origin');self.invalidate();self.plan();return
        if a=='point':
            field=b.get('field');lon=b.get('lon');lat=b.get('lat')
            if field not in ('origin','destination') or type(lon) not in (int,float) or type(lat) not in (int,float) or not inside(lon,lat):raise Error('请在 Waterloo 支持区域内选点')
            self.invalidate();s[field]={'id':secrets.token_hex(6),'name':'地图选点 '+f'{lat:.5f}, {lon:.5f}','lon':lon,'lat':lat};self.plan();return
        if a=='search':
            field=b.get('field');text=b.get('text')
            if field not in ('origin','destination') or not isinstance(text,str) or not 1<=len(text)<=300:raise Error('请输入有效的地点名称')
            self.invalidate();s.pop(field,None);self.search(field,text);return
        if a=='choose':
            pending=s.get('pending') or {};choice=next((p for p in pending.get('options',[]) if p['id']==b.get('id')),None)
            if not choice:raise Error('请选择列表中的地点')
            s[pending['field']]=choice;s.pop('pending',None)
            if s.get('next_search'):
                field,text=s.pop('next_search');self.search(field,text)
            else:self.plan()
            return
        if a=='message':
            text=b.get('text')
            if not isinstance(text,str) or not 1<=len(text)<=2000:raise Error('请输入路线需求')
            reserve();r=intent(text,s)
            if r['question']:s['question']=r['question'];s['message']=r['question'];return
            self.invalidate();s.pop('next_search',None);s.pop('question',None)
            searches=[(f,r[f]) for f in ('origin','destination') if r[f]]
            for f,_ in searches:s.pop(f,None)
            if len(searches)>1:s['next_search']=searches[1]
            if searches:self.search(*searches[0])
            else:self.plan()
            return
        if a=='plan':self.plan();return
        raise Error('Unsupported action')
    def search(self,field,text):
        options=self.provider.geocode(text)
        for i,p in enumerate(options):p['id']=p['id'] or str(i)
        self.state['pending']={'field':field,'options':options};self.state['message']='请在下方确认'+('起点' if field=='origin' else '终点')+'。' if options else '未找到地点，请换个名称，或直接点击地图选点。'
    def plan(self):
        s=self.state;s.pop('pending',None)
        if not s.get('origin') or not s.get('destination'):
            s['message']='请继续设置'+('起点' if not s.get('origin') else '终点')+'。';return
        a,b=s['origin'],s['destination']
        if distance((a['lon'],a['lat']),(b['lon'],b['lat']))<10:raise Error('起终点太近，请选择相距至少 10 米的地点')
        started=time.monotonic();base=self.provider.route([a,b]);routes=[base];trace=[{'strategy':'short','distance_m':base['distance_m']}]
        if base['distance_m']>15000:raise Error('当前支持 15 公里以内的步行路线',422)
        ps=points(base);partial=False
        attempts=[('balanced',None),('short',ps[len(ps)//2]),('short',ps[len(ps)//3])]
        for kind,avoid in attempts:
            if len(routes)>=3:break
            if time.monotonic()-started>32:partial=True;break
            try:r=self.provider.route([a,b],route_type=kind,avoid=avoid)
            except Error:partial=True;continue
            accepted=r['distance_m']<=min(15000,base['distance_m']*1.8+150) and distinct(r,routes)
            trace.append({'strategy':kind if not avoid else 'avoid_midroute_location','distance_m':r['distance_m'],'distinct_accepted':accepted})
            if accepted:routes.append(r)
        routes.sort(key=lambda r:r['distance_m'])
        for i,r in enumerate(routes):r.update(id=secrets.token_hex(8),color=['#2563eb','#e07b16','#8b46cf'][i],recommended=i==0)
        s['routes']=routes;s['selected']=routes[0]['id'];s['trace']=trace
        s['message']=f'找到 {len(routes)} 条不同路线，已推荐候选中距离最短的一条。'+('部分备选请求未完成。' if partial else '')+('未找到更多不同路线，不重复展示相同路径。' if len(routes)==1 else '点击路线或卡片可切换。')
