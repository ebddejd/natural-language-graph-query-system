"""GRT scheduled transit routing. No external journey-planner or realtime claims.
Bounded round-based search: up to 3 boardings, up to 6 access/egress stops each,
4-hour horizon. All walking links in returned itineraries are road-validated.
"""
import csv, io, json, math, threading, time, zipfile, urllib.request, os
from pathlib import Path
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from core import Error
from walking import distance

TZ=ZoneInfo('America/Toronto')
DATA=Path(__file__).parent/'data/grt'
URL='https://webapps.regionofwaterloo.ca/api/grt-routes/api/staticfeeds/'
ATTRIBUTION='Contains information provided by the Regional Municipality of Waterloo under licence'

def seconds(value):
    h,m,s=map(int,value.split(':'));return h*3600+m*60+s

def now_local():return datetime.now(TZ)

def departure(value=None):
    if not value:return now_local().replace(second=0,microsecond=0)
    try:
        d=datetime.fromisoformat(value)
        if d.tzinfo is not None:raise ValueError()
        d=d.replace(tzinfo=TZ)
        if d.astimezone(ZoneInfo('UTC')).astimezone(TZ).replace(tzinfo=None)!=d.replace(tzinfo=None):raise ValueError()
        if abs((d-now_local()).total_seconds())>31*86400:raise ValueError()
        return d
    except (ValueError,TypeError):raise Error('Choose a valid Waterloo departure time within 31 days.',400)

def coord(p):return p['lon'],p['lat']
def clock(t):return datetime.fromtimestamp(t,TZ).strftime('%H:%M')
def stamp(t):return datetime.fromtimestamp(t,TZ).isoformat()

class Dataset:
    def __init__(self,files):
        self.stops={};self.trips={};self.services={};self.shapes={};self.ranges={}
        for prefix,path in files:
            with zipfile.ZipFile(path) as z:
                if sum(i.file_size for i in z.infolist())>80_000_000:raise ValueError('GTFS too large')
                def rows(name):
                    if name not in z.namelist():return []
                    return csv.DictReader(io.TextIOWrapper(z.open(name),encoding='utf-8-sig'))
                routes={r['route_id']:r for r in rows('routes.txt')}
                for r in rows('stops.txt'):
                    if r.get('location_type','0') not in ('','0'):continue
                    sid=prefix+r['stop_id'];self.stops[sid]={'id':sid,'code':r.get('stop_code') or r['stop_id'],'name':r['stop_name'],'lat':float(r['stop_lat']),'lon':float(r['stop_lon'])}
                service=defaultdict(set)
                for r in rows('calendar.txt'):
                    d=datetime.strptime(r['start_date'],'%Y%m%d').date();end=datetime.strptime(r['end_date'],'%Y%m%d').date()
                    while d<=end:
                        if r[d.strftime('%A').lower()]=='1':service[d.strftime('%Y%m%d')].add(r['service_id'])
                        d+=timedelta(days=1)
                for r in rows('calendar_dates.txt'):
                    if r['exception_type']=='1':service[r['date']].add(r['service_id'])
                    else:service[r['date']].discard(r['service_id'])
                self.services[prefix]=dict(service)
                active=[k for k,v in service.items() if v]
                self.ranges[prefix]=(min(active),max(active))
                shapes=defaultdict(list)
                for r in rows('shapes.txt'):shapes[prefix+r['shape_id']].append((int(r['shape_pt_sequence']),[float(r['shape_pt_lon']),float(r['shape_pt_lat'])]))
                for key,pts in shapes.items():self.shapes[key]=[p for _,p in sorted(pts)]
                trips={}
                for r in rows('trips.txt'):
                    rt=routes[r['route_id']];tid=prefix+r['trip_id']
                    trips[tid]={'id':tid,'prefix':prefix,'service':r['service_id'],'route':rt['route_short_name'],'name':rt['route_long_name'],'headsign':r.get('trip_headsign',''),'vehicle':'ION light rail' if rt['route_type'] in ('0','1','2') else 'Bus','shape':prefix+r.get('shape_id',''),'times':[]}
                for r in rows('stop_times.txt'):
                    tid=prefix+r['trip_id'];sid=prefix+r['stop_id']
                    if tid not in trips or sid not in self.stops:continue
                    try:arr=seconds(r['arrival_time']);dep=seconds(r['departure_time'])
                    except ValueError:continue
                    trips[tid]['times'].append((int(r['stop_sequence']),sid,arr,dep,r.get('pickup_type','0') in ('','0'),r.get('drop_off_type','0') in ('','0')))
                for tid,t in trips.items():
                    t['times'].sort();ts=t['times']
                    if len(ts)>1 and all(x[2]<=x[3] and (i==0 or ts[i-1][3]<=x[2]) for i,x in enumerate(ts)):self.trips[tid]=t
        # Candidate footpaths only. Every one used in an output is verified with walking routing.
        self.neighbors={};grid=defaultdict(list)
        for sid,p in self.stops.items():grid[(int(p['lon']/.003),int(p['lat']/.002))].append(sid)
        for sid,p in self.stops.items():
            x,y=int(p['lon']/.003),int(p['lat']/.002);near=[]
            for dx in (-1,0,1):
                for dy in (-1,0,1):
                    for other in grid.get((x+dx,y+dy),[]):
                        if other==sid:continue
                        meters=distance(coord(p),coord(self.stops[other]))
                        if meters<=200:near.append((other,math.ceil(meters*1.4/1.2)+120))
            self.neighbors[sid]=near
    def runs(self,start):
        found=[];date=start.date();last=start.timestamp()+4*3600
        for delta in (-1,0,1):
            d=date+timedelta(days=delta);ds=d.strftime('%Y%m%d')
            # GTFS service seconds use local noon minus 12h, including DST changes.
            base=datetime(d.year,d.month,d.day,12,tzinfo=TZ).timestamp()-43200
            active={p:services.get(ds,set()) for p,services in self.services.items()}
            for t in self.trips.values():
                ts=t['times']
                if t['service'] in active[t['prefix']] and base+ts[-1][2]>=start.timestamp() and base+ts[0][3]<=last:found.append((t,base))
        return found
    def line(self,trip,i,j):
        shape=self.shapes.get(trip['shape'],[]);stops=[self.stops[t[1]] for t in trip['times'][i:j+1]]
        if not shape:return [list(coord(s)) for s in stops],True
        # Monotone nearest shape matches stop order, including loop routes.
        indexes=[];floor=0
        for t in trip['times'][:j+1]:
            p=self.stops[t[1]];idx=min(range(floor,len(shape)),key=lambda n:distance(coord(p),shape[n]));indexes.append(idx);floor=idx
        lo,hi=indexes[i],indexes[j]
        if hi<=lo:return [list(coord(s)) for s in stops],True
        return shape[lo:hi+1],False

_dataset=None;_lock=threading.Lock();_refreshing=False;_last_attempt=0

def get_dataset():
    global _dataset,_refreshing,_last_attempt
    with _lock:
        if _dataset is None:_dataset=Dataset([('bus:',DATA/'bus.zip'),('lrt:',DATA/'lrt.zip')])
        # Refresh in background at most once per day. Keep validated snapshot on failure.
        meta=json.loads((DATA/'metadata.json').read_text())
        if time.time()-meta['downloaded_at']>86400 and time.time()-_last_attempt>86400 and not _refreshing:
            _refreshing=True;_last_attempt=time.time();threading.Thread(target=refresh,daemon=True).start()
        return _dataset,meta

def refresh():
    global _dataset,_refreshing
    try:
        for name,num in [('bus',1),('lrt',2)]:
            with urllib.request.urlopen(URL+str(num),timeout=25) as r:data=r.read(20_000_001)
            if len(data)>20_000_000:raise ValueError('Feed too large')
            (DATA/(name+'.next')).write_bytes(data)
        candidate=Dataset([('bus:',DATA/'bus.next'),('lrt:',DATA/'lrt.next')])
        with _lock:
            for name in ('bus','lrt'):os.replace(DATA/(name+'.next'),DATA/(name+'.zip'))
            (DATA/'metadata.json').write_text(json.dumps({'downloaded_at':time.time(),'sources':[URL+'1',URL+'2']}))
            _dataset=candidate
    except Exception:pass # old snapshot remains usable only within its service dates
    finally:_refreshing=False

class TransitPlanner:
    def __init__(self,provider,dataset=None):self.provider=provider;self.dataset=dataset
    def walks(self,ds,a,b):
        def nearest(p):
            candidates=sorted((distance(coord(p),coord(s)),sid) for sid,s in ds.stops.items() if distance(coord(p),coord(s))<=1000)
            selected=candidates[:4]
            for rail in [v for v in candidates if v[1].startswith('lrt:')][:2]:
                if rail not in selected:selected.append(rail)
            return selected
        tasks=[('access',sid,a,ds.stops[sid]) for _,sid in nearest(a)]+[('egress',sid,ds.stops[sid],b) for _,sid in nearest(b)]
        if not tasks:raise Error('No nearby GRT stops. Choose an endpoint closer to a transit stop.',422)
        def calc(task):
            kind,sid,p,q=task
            try:
                if distance(coord(p),coord(q))<15:r={'distance_m':distance(coord(p),coord(q)),'duration_s':15,'geometry':{'type':'LineString','coordinates':[coord(p),coord(q)]},'steps':[]}
                else:r=self.provider.route([p,q],mode='walk')
                if r['distance_m']>1500:return None
                return kind,sid,r
            except Error:return None
        result={'access':{},'egress':{}}
        with ThreadPoolExecutor(max_workers=3) as pool:
            for item in pool.map(calc,tasks):
                if item:kind,sid,r=item;result[kind][sid]=r
        if not all(result.values()):raise Error('Could not find walkable access to nearby GRT stops. Try moving the endpoints closer to a stop.',422)
        return result
    def search(self,ds,runs,start,walks,verified,blocked,constraints=None):
        constraints=constraints or {}
        # label = arrival timestamp, immutable tuple of legs
        labels={sid:(start+r['duration_s']+60,({'kind':'walk','purpose':'access','to':sid,'route':r,'start':start,'end':start+r['duration_s']},)) for sid,r in walks['access'].items()}
        solutions=[];horizon=start+4*3600
        for round_no in range(1,constraints.get("max_transfers",2)+2):
            ride_labels={}
            for trip,base in runs:
                if constraints.get('avoid_rail') and trip['vehicle']=='ION light rail':continue
                boarded=None
                for i,t in enumerate(trip['times']):
                    _,sid,arr,dep,pick,drop=t;arrival=base+arr;depart=base+dep
                    if arrival>horizon:break
                    if boarded is not None and drop:
                        j,path=boarded
                        leg={'kind':'ride','trip':trip['id'],'i':j,'j':i,'start':base+trip['times'][j][3],'end':arrival}
                        prev=ride_labels.get(sid)
                        if prev is None or arrival<prev[0]:ride_labels[sid]=(arrival,path+(leg,))
                    prev=labels.get(sid)
                    if boarded is None and pick and prev and prev[0]<=depart:
                        previous={ds.trips[l['trip']]['route'] for l in prev[1] if l['kind']=='ride'}
                        if trip['route'] not in previous:boarded=(i,prev[1])
            for sid,(arrival,path) in ride_labels.items():
                if sid in walks['egress']:
                    w=walks['egress'][sid];end=arrival+w['duration_s']
                    if end<=horizon:solutions.append((end,path+({'kind':'walk','purpose':'egress','from':sid,'route':w,'start':arrival,'end':end},)))
            labels={sid:(t+120,path) for sid,(t,path) in ride_labels.items()}
            for sid,(t,path) in ride_labels.items():
                for other,estimate in ds.neighbors[sid]:
                    key=(sid,other)
                    if key in blocked:continue
                    r=verified.get(key);cost=r['duration_s']+120 if r else estimate
                    arrival=t+cost
                    if other not in labels or arrival<labels[other][0]:labels[other]=(arrival,path+({'kind':'walk','purpose':'transfer','from':sid,'to':other,'route':r,'start':t,'end':t+cost-120},))
        solutions.sort(key=lambda x:x[0]);out=[];seen=set()
        for end,path in solutions:
            limit=constraints.get('max_walk_minutes')
            if limit is not None and sum(l['route']['duration_s'] if l['route'] else l['end']-l['start'] for l in path if l['kind']=='walk')>limit*60:continue
            if out and end>out[0][0]+1800:continue
            signature=tuple((ds.trips[l['trip']]['route'],ds.trips[l['trip']]['headsign']) for l in path if l['kind']=='ride')
            if signature in seen:continue
            walk=sum(l['route']['distance_m'] if l['route'] else distance(coord(ds.stops[l['from']]),coord(ds.stops[l['to']]))*1.4 for l in path if l['kind']=='walk')
            count=len(signature)
            if any(other_end<=end and sum(l['kind']=='ride' for l in other_path)<=count and sum(l['route']['distance_m'] if l['route'] else distance(coord(ds.stops[l['from']]),coord(ds.stops[l['to']]))*1.4 for l in other_path if l['kind']=='walk')<=walk for other_end,other_path in out):continue
            seen.add(signature);out.append((end,path))
            if len(out)==8:break
        return out
    def plan(self,a,b,when=None,constraints=None,arrive_by=False):
        target=departure(when);constraints=constraints or {}
        ds,meta=(self.dataset,{'downloaded_at':time.time()}) if self.dataset else get_dataset()
        date=target.strftime('%Y%m%d')
        if not any(lo<=date<=hi for lo,hi in ds.ranges.values()):raise Error('The GRT timetable does not cover this date. Choose a date within the published service period.',422)
        # Arrival planning samples a bounded four-hour departure window. Reuse all
        # verified walking links across samples; never claim global optimality.
        starts=[target-timedelta(minutes=m) for m in range(20,241,20)] if arrive_by else [target]
        walks=self.walks(ds,a,b);verified={};blocked=set();valid=[];deadline=time.monotonic()+35;checks=0;seen=set()
        for start in starts:
            runs=ds.runs(start)
            if not runs:continue
            for attempt in range(4):
                candidates=self.search(ds,runs,start.timestamp(),walks,verified,blocked,constraints)
                if arrive_by:candidates=[(end,path) for end,path in candidates if end<=target.timestamp()]
                pending=set()
                for _,path in candidates[:3]:
                    for l in path:
                        if l['kind']=='walk' and l['purpose']=='transfer' and (l['from'],l['to']) not in verified:pending.add((l['from'],l['to']))
                if not pending:break
                for key in pending:
                    if checks>=8 or time.monotonic()>deadline:blocked.add(key);continue
                    checks+=1
                    try:
                        r=self.provider.route([ds.stops[key[0]],ds.stops[key[1]]],mode='walk')
                        if r['distance_m']>500:blocked.add(key)
                        else:verified[key]=r
                    except Error:blocked.add(key)
            for end,path in self.search(ds,runs,start.timestamp(),walks,verified,blocked,constraints):
                if arrive_by and end>target.timestamp():continue
                if any(l['kind']=='walk' and l['purpose']=='transfer' and (l['from'],l['to']) not in verified for l in path):continue
                signature=tuple((l['trip'],l['start'],l['i'],l['j']) for l in path if l['kind']=='ride')
                if signature in seen:continue
                seen.add(signature);actual_start=start.timestamp()
                if arrive_by:
                    first=next(l for l in path if l['kind']=='ride')
                    actual_start=first['start']-path[0]['route']['duration_s']-60
                    access=dict(path[0],start=actual_start,end=first['start']-60)
                    path=(access,)+path[1:]
                if arrive_by and target>now_local() and actual_start<now_local().timestamp():continue
                valid.append(self.itinerary(ds,path,actual_start,end,meta))
        if not valid:raise Error('No verified scheduled itinerary met these constraints in the four-hour search window. Try another time or explicitly relax a requirement.',422)
        pref=constraints.get('preference','fastest')
        key={'least_walking':lambda r:(sum(l['duration_s'] for l in r['legs'] if l['kind']=='walk'),r['duration_s']),'fewest_transfers':lambda r:(r['transfers'],r['duration_s']),'shortest':lambda r:(r['distance_m'],r['duration_s'])}.get(pref,lambda r:r['duration_s'])
        valid.sort(key=key)
        return valid[:3]
    def itinerary(self,ds,path,start,end,meta):
        legs=[];lines=[];total=0;steps=[];ride_no=0
        for l in path:
            if l['kind']=='walk':
                r=l['route'];g=r['geometry'];coords=g['coordinates'];segments=coords if g['type']=='MultiLineString' else [coords]
                title='Walk to '+ds.stops[l['to']]['name'] if l.get('to') else 'Walk to your destination'
                leg={'kind':'walk','purpose':l['purpose'],'title':title,'distance_m':r['distance_m'],'duration_s':r['duration_s'],'geometry':g,'steps':r['steps'],'departure':stamp(l['start']),'arrival':stamp(l['end'])}
                total+=r['distance_m'];lines.extend(segments);steps.append(title)
            else:
                ride_no+=1;t=ds.trips[l['trip']];board=ds.stops[t['times'][l['i']][1]];alight=ds.stops[t['times'][l['j']][1]];coords,approx=ds.line(t,l['i'],l['j'])
                meters=sum(distance(x,y) for x,y in zip(coords,coords[1:]));total+=meters;lines.append(coords)
                leg={'kind':'ride','vehicle':t['vehicle'],'route':t['route'],'name':t['name'],'headsign':t['headsign'],'board':board,'alight':alight,'stops':l['j']-l['i'],'departure':stamp(l['start']),'arrival':stamp(l['end']),'geometry':{'type':'LineString','coordinates':coords},'schematic':approx,'distance_m':meters,'duration_s':l['end']-l['start']}
                steps.append(f"{'Transfer to' if ride_no>1 else 'Board'} {t['vehicle']} {t['route']} toward {t['headsign']} at {board['name']} ({clock(l['start'])}); get off at {alight['name']} ({clock(l['end'])}).")
            legs.append(leg)
        return {'geometry':{'type':'MultiLineString','coordinates':lines},'distance_m':total,'duration_s':end-start,'steps':steps,'legs':legs,'transit':True,'transfers':ride_no-1,'departure':stamp(start),'arrival':stamp(end),'walk_m':sum(l['distance_m'] for l in legs if l['kind']=='walk'),'data_downloaded':stamp(meta['downloaded_at']),'service_ranges':ds.ranges,'attribution':ATTRIBUTION}
