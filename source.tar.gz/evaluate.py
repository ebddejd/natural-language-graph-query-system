"""Deterministic 72-case benchmark. Real-provider runs only with explicit --mode."""
import argparse, json, time, statistics, contextlib, io
from app import Service
from core import Error, ROOT
from planner import completion
from tests.test_system import oracle

def cases():
    out=[]
    for s in range(1,9):
        for t in [1,6,8]:
            for style in ['en','zh']:
                args={'source':s,'target':t,'operation':'shortest_path','avoid_nodes':[],'avoid_edges':[]}
                out.append({'text':f'from {s} to {t}' if style=='en' else f'从{s}到{t}','arguments':args,'kind':'route'})
    for node in [2,3,4,5,7]:
        for style in ['en','zh']:
            out.append({'text':f'from 1 to 6 avoid node {node}' if style=='en' else f'从1到6，避开节点{node}','arguments':{'source':1,'target':6,'operation':'shortest_path','avoid_nodes':[node],'avoid_edges':[]},'kind':'route'})
    for edge in [[1,2],[1,3],[3,7],[5,6]]:
        out.append({'text':f'from 1 to 6 avoid edge {edge[0]}-{edge[1]}','arguments':{'source':1,'target':6,'operation':'shortest_path','avoid_nodes':[],'avoid_edges':[edge]},'kind':'route'})
    for q in ['find a path','从哪里走','from 1 to 6 fastest driving route','from 1 to 6 via 4','delete graph','find shortest distance in kilometres']:
        out.append({'text':q,'kind':'clarify'})
    for q,a in [('from 0 to 2',{'source':0,'target':2}),('from 1 to 99',{'source':1,'target':99}),('from 1 to 6 avoid node 1',{'source':1,'target':6,'avoid_nodes':[1]}),('from 1 to 6 avoid node 99',{'source':1,'target':6,'avoid_nodes':[99]})]:out.append({'text':q,'arguments':a,'kind':'invalid'})
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['demo','structured','llm','direct-llm'],default='demo');p.add_argument('--limit',type=int);a=p.parse_args()
    service=Service();snap=service.store.get(); rows=[]
    suite=cases();(ROOT/'data/benchmark.json').write_text(json.dumps(suite,ensure_ascii=False,indent=2))
    for c in suite[:a.limit]:
        if a.mode=='structured' and c['kind']=='clarify':continue
        start=time.perf_counter();ok=False;usage={};r={};param=None
        try:
            if a.mode=='direct-llm':
                msg,usage=completion([{'role':'system','content':'Solve the undirected unweighted graph task directly. Return only JSON: {"path":[vertex IDs],"clarify":false,"invalid":false}. Empty path means unreachable. Set clarify for unsupported or underspecified requests and invalid for invalid vertices/exclusions. Graph: '+json.dumps(snap.public())},{'role':'user','content':c['text']}])
                result=json.loads(msg['content']);r=result
                if c['kind']=='clarify':ok=result.get('clarify') is True
                elif c['kind']=='invalid':ok=result.get('invalid') is True
                else:ok=grade_path(snap,c['arguments'],result.get('path'))
            else:
                body={'mode':a.mode,'arguments':c.get('arguments'),'text':c['text']}
                with contextlib.redirect_stdout(io.StringIO()):r=service.query(body)
                usage=r.get('usage',{})
                if c['kind']=='clarify':ok=r['status']=='clarification'
                elif c['kind']=='route':
                    param=r.get('tool_call',{}).get('arguments')==c['arguments']
                    ok=r['status']=='ok' and grade_path(snap,c['arguments'],r.get('path')) and param
        except Error as e:
            ok=c['kind']=='invalid' and e.status==400;r={'error':str(e),'status':e.status}
        except (ValueError,KeyError,TypeError) as e:r={'error':str(e)}
        rows.append({'text':c['text'],'kind':c['kind'],'passed':ok,'parameters_correct':param,'latency_ms':round((time.perf_counter()-start)*1000,3),'usage':usage,'result':r})
    times=sorted(r['latency_ms'] for r in rows)
    report={'mode':a.mode,'model':__import__('os').getenv('LLM_MODEL') if 'llm' in a.mode else None,'cases':len(rows),'passed':sum(r['passed'] for r in rows),'p50_ms':statistics.median(times),'p95_ms':times[min(len(times)-1,int(len(times)*.95))], 'note':'Local demo results do not measure LLM quality. Costs not estimated: use provider token rates. Latency includes process startup.','rows':rows}
    path=ROOT/'reports'/f'{a.mode}.json';path.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))

def grade_path(snap,args,path):
    if not isinstance(path,list) or any(type(x)is not int for x in path):return False
    distance=oracle(snap,args)
    if distance is None:return path==[]
    if not path or path[0]!=args['source'] or path[-1]!=args['target'] or len(path)-1!=distance:return False
    blocked=set(args.get('avoid_nodes',[]));excluded={tuple(sorted(e)) for e in args.get('avoid_edges',[])}
    return not blocked.intersection(path) and all(tuple(sorted(e)) in snap.edges and tuple(sorted(e)) not in excluded for e in zip(path,path[1:]))
if __name__=='__main__':main()
