import copy,json,unittest
from unittest.mock import patch
from datetime import datetime
from journey_agent import DEFAULT,FIELDS,extract,merge,execute,validate
from navigation import NavigationSession
from core import Error
from test_transit import fixture,Walk
from transit import TransitPlanner,now_local

def args(**changes):
    a={k:None for k in FIELDS};a['clear']=[];a.update(changes);return a
class AgentTests(unittest.TestCase):
    def test_followup_preserves_and_clears(self):
        p=merge(None,args(max_walk_minutes=15,max_transfers=1,avoid_rail=True))
        q=merge(p,args(max_walk_minutes=10,fallback_drive_over_minutes=45))
        self.assertEqual(q['max_transfers'],1);self.assertTrue(q['avoid_rail']);self.assertEqual(q['max_walk_minutes'],10)
        self.assertIsNone(merge(q,args(clear=['max_walk_minutes']))['max_walk_minutes'])
    def test_tool_validation_and_private_coordinates(self):
        a=args(modes=['walk']);s={'origin':{'name':'Map pin 43.12345, -80.54321','lon':-80.54321,'lat':43.12345}}
        with patch('journey_agent.completion',return_value=({'tool_calls':[{'function':{'name':'update_journey','arguments':json.dumps(a)}}]},{})) as model:
            self.assertEqual(extract('walk',s)[0],a)
            self.assertNotIn('43.12345',str(model.call_args));self.assertNotIn('-80.54321',str(model.call_args))
        for bad in [args(max_transfers=3),args(max_walk_minutes=-1),args(modes=['flight']),args(avoid_rail='yes')]:
            with self.assertRaises(ValueError):validate(bad)
    def test_clarification_keeps_partial_requirements_and_endpoints(self):
        class Geo(Walk):
            def geocode(self,text):return [{'id':text,'name':text,'lon':-80.53,'lat':43.47}]
        s=NavigationSession(Geo())
        with patch('journey_agent.extract',return_value=(args(origin='Library',max_walk_minutes=10,question='Which school?'),{})):
            r=s.handle({'revision':0,'action':'message','text':'Library to school, 10 min walking'})
        self.assertEqual(r['agent_plan']['max_walk_minutes'],10)
        with patch('journey_agent.extract',return_value=(args(destination='University'),{})):
            r=s.handle({'revision':1,'action':'message','text':'University'})
        self.assertEqual(r['pending']['field'],'origin');self.assertEqual(s.state['next_search'],('destination','University'))
    def test_rejects_route_that_fails_walking_limit(self):
        d=fixture();p=merge(None,args(modes=['walk'],max_walk_minutes=0))
        routes,trace,msg=execute(Walk(),d.stops['a'],d.stops['d'],p)
        self.assertEqual(routes,[]);self.assertEqual(trace[0]['constraints_passed'],0);self.assertIn('unchanged',msg)
    def test_conditional_fallback_and_comparison(self):
        d=fixture();p=merge(None,args(fallback_drive_over_minutes=45))
        with patch('journey_agent.TransitPlanner.plan',side_effect=Error('No service')):
            routes,trace,msg=execute(Walk(),d.stops['a'],d.stops['d'],p)
        self.assertEqual(routes[0]['travel_mode'],'drive');self.assertTrue(next(t for t in trace if t['tool']=='evaluate_driving_fallback')['triggered'])
        p=merge(None,args(modes=['walk','drive']))
        routes,_,_=execute(Walk(),d.stops['a'],d.stops['d'],p)
        self.assertEqual({r['travel_mode'] for r in routes},{'walk','drive'})
    def test_no_fallback_when_transit_fast_enough(self):
        d=fixture();p=merge(None,args(modes=['transit','drive'],fallback_drive_over_minutes=45))
        r={'duration_s':1200,'distance_m':1000,'transfers':0,'legs':[]}
        with patch('journey_agent.TransitPlanner.plan',return_value=[r]):
            routes,trace,_=execute(Walk(),d.stops['a'],d.stops['d'],p)
        self.assertFalse(next(t for t in trace if t['tool']=='evaluate_driving_fallback')['triggered']);self.assertEqual(len(routes),1)
    def test_transit_constraints_and_arrival_deadline(self):
        d=fixture();planner=TransitPlanner(Walk(),d);when=now_local().strftime('%Y-%m-%d')+'T12:00'
        for constraints in [{'max_transfers':0},{'max_walk_minutes':0}]:
            with self.assertRaises(Error):planner.plan(d.stops['a'],d.stops['d'],when,constraints=constraints)
        d.trips['one']['vehicle']='ION light rail'
        with self.assertRaises(Error):planner.plan(d.stops['a'],d.stops['d'],when,constraints={'avoid_rail':True})
        d.trips['one']['vehicle']='Bus'
        deadline=when.replace('12:00','12:35')
        r=planner.plan(d.stops['a'],d.stops['d'],deadline,arrive_by=True)[0]
        self.assertLessEqual(datetime.fromisoformat(r['arrival']).strftime('%H:%M'),'12:35')
        self.assertIn('12:03',r['departure'])
        with self.assertRaises(Error):planner.plan(d.stops['a'],d.stops['d'],when.replace('12:00','12:20'),arrive_by=True)
    def test_arrival_evidence_for_walk(self):
        d=fixture();p=merge(None,args(modes=['walk'],time_kind='arrive',time=now_local().strftime('%Y-%m-%d')+'T20:00'))
        routes,_,_=execute(Walk(),d.stops['a'],d.stops['d'],p)
        self.assertTrue(all(c['passed'] for c in routes[0]['checks']));self.assertIn('20:00',routes[0]['arrival'])
