// Browser-independent regression tests for the location permission flow.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync('web/navigation.html','utf8').match(/<script>([\s\S]*)<\/script>/)[1];
async function run(error){
 const nodes=new Map(),calls=[];let coords;
 const node=id=>{if(!nodes.has(id))nodes.set(id,{value:'',classList:{toggle(){}},style:{setProperty(){}},setAttribute(){},replaceChildren(){},append(){}});return nodes.get(id)};
 const state={revision:0,mode:'walk',message:'Ready',origin:null,destination:null,routes:[]};
 const context={window:{},document:{getElementById:node,querySelectorAll:()=>[],createElement:()=>node(Symbol()),createTextNode:x=>x},URLSearchParams,console,
 navigator:{geolocation:{getCurrentPosition(ok,fail,options){assert.equal(options.timeout,15000);if(error)fail({code:error});else ok({coords:{latitude:43.47,longitude:-80.53,accuracy:12}})}}},
 fetch:async(url,opts)=>{if(opts){coords=JSON.parse(opts.body);calls.push(coords);state.origin={name:'Current location',lat:coords.lat,lon:coords.lon};}return {ok:true,json:async()=>({...state})}}};
 vm.createContext(context);vm.runInContext(source,context);await new Promise(setImmediate);node('locate').onclick();await new Promise(setImmediate);
 if(error){assert.equal(calls.length,0);assert.equal(node('status').className,'status error');assert.match(node('status').textContent,error===1?/denied/:/timed out/)}
 else {assert.equal(coords.field,'origin');assert.equal(coords.current_location,true);assert.match(node('hint').textContent,/Destination/);assert.match(node('status').textContent,/12 m/)}
}
(async()=>{await run();await run(1);await run(3);console.log('Location success, permission denial and timeout checks passed')})().catch(e=>{console.error(e);process.exit(1)});
