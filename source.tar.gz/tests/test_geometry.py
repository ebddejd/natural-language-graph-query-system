import copy, unittest
from geometry_validation import _export
from core import Store, Error

class GeometryTests(unittest.TestCase):
    def test_crossing(self):
        graph=_export.from_roads({'East':[[0,0],[4,0]],'North':[[2,-2],[2,2]]})
        snap=Store().publish(graph)
        self.assertEqual((snap.n,len(snap.edges)),(5,4))
        coords=graph['geometry']['coordinates'];i=coords.index(['2','0'])+1
        self.assertEqual(sum(i in edge for edge in snap.edges),4)
    def test_fractional_and_rename(self):
        graph=_export.from_roads({'A':[[0,0],[3,3]],'B':[[0,2],[3,0]]})
        self.assertIn(['6/5','6/5'],graph['geometry']['coordinates'])
        store=Store();before=store.publish(graph)
        graph['streets']['Renamed']=graph['streets'].pop('A')
        graph['geometry']['roads']['Renamed']=graph['geometry']['roads'].pop('A')
        self.assertEqual(store.publish(graph).edges,before.edges)
    def test_corrupt_update_is_atomic(self):
        graph=_export.from_roads({'A':[[0,0],[4,0]],'B':[[2,-2],[2,2]]})
        store=Store();before=store.publish(graph)
        for kind in ('coordinate','edge','membership'):
            bad=copy.deepcopy(graph)
            if kind=='coordinate':bad['geometry']['coordinates'][0]=['999','999']
            elif kind=='edge':bad['edges'].pop()
            else:bad['streets']['A']=[]
            with self.assertRaises(Error):store.publish(bad)
            self.assertEqual(store.get(),before)
