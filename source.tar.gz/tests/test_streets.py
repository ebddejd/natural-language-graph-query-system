import unittest,json,importlib.util,contextlib,io,os
from pathlib import Path
from unittest.mock import patch
from core import Store,Engine,Error,ROOT
from planner import plan
from app import Service,SAMPLE
import model_config
class StreetsTests(unittest.TestCase):
    def setUp(self):self.store=Store();self.s=self.store.publish(SAMPLE);self.e=Engine()
    def test_named_route_and_intersection(self):
        self.assertEqual(self.e.execute(self.s,{'source':'King Street','target':'University Avenue'})['hops'],1)
        self.assertEqual(self.e.execute(self.s,{'source':'King Street','target':'Columbia Street'})['hops'],0)
        self.assertEqual(self.e.execute(self.s,{'source':'king street','target':6})['hops'],2)
    def test_street_exclusion(self):
        self.assertFalse(self.e.execute(self.s,{'source':'King Street','target':6,'avoid_streets':['Columbia Street']})['reachable'])
        r=self.e.execute(self.s,{'source':1,'target':6,'avoid_streets':['University Avenue']})
        self.assertEqual(r['path'],[1,2,4,5,6])
    def test_names_validation_and_version(self):
        for args in [{'source':'Unknown','target':2},{'source':1,'target':2,'avoid_streets':['Unknown']}]:
            with self.assertRaises(Error):self.e.execute(self.s,args)
        g=json.loads(json.dumps(self.s.public()));g['streets']['国王街']=g['streets'].pop('King Street');new=self.store.publish(g)
        self.assertEqual(self.e.execute(new,{'source':'国王街','target':6})['hops'],2)
        self.assertEqual(self.e.execute(self.s,{'source':'King Street','target':6})['hops'],2)
        g['streets']['bad']=[[1,8]]
        with self.assertRaises(Error):self.store.publish(g)
        self.assertEqual(self.store.get(),new)
    def test_geometry_membership(self):
        spec=importlib.util.spec_from_file_location('export_graph',ROOT/'generator/export_graph.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        g=m.convert('add "horizontal" (0,0) (4,0)\nadd "vertical" (2,-2) (2,2)\ngg\n')
        s=self.store.publish(g)
        self.assertEqual(s.n,5);self.assertEqual(len(s.edges),4)
        self.assertEqual([len(e) for n,e in s.streets],[2,2])
        self.assertEqual(self.e.execute(s,{'source':'horizontal','target':'vertical'})['hops'],0)
    def test_model_named_tool(self):
        msg={'tool_calls':[{'function':{'name':'query_graph','arguments':json.dumps({'source':'King Street','target':'University Avenue','avoid_nodes':[4],'avoid_streets':[]})}}]}
        with patch('planner.completion',return_value=(msg,{'total_tokens':10})) as c:
            call,_=plan('从King Street到University Avenue，不走节点4','llm',self.s)
            self.assertIn('King Street',c.call_args[0][0][0]['content'])
            self.assertEqual(self.e.execute(self.s,call['arguments'])['hops'],1)
    def test_config_does_not_expose_secret(self):
        with patch.object(model_config,'_settings',None):
            result=model_config.configure({'base_url':'https://example.com/v1','model':'test','api_key':'test-secret'})
            self.assertNotIn('test-secret',json.dumps(result));self.assertTrue(result['configured'])
            with self.assertRaises(Error):model_config.configure({'base_url':'http://remote.example/v1','model':'x','api_key':'x'})
            with self.assertRaises(Error):model_config.configure({'base_url':'https://user:pass@example.com/v1','model':'x','api_key':'x'})
