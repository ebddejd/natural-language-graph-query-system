import io,json,unittest
from unittest.mock import patch
from hosted import HostedApp
import model_config

class HostedTests(unittest.TestCase):
    def setUp(self):
        with patch.dict('os.environ',{'LLM_API_KEY':'owner-test-secret','LLM_MODEL':'test-model'}):self.app=HostedApp('https://graphs.example')
    def call(self,path,body=None,cookie='',origin='https://graphs.example',host='graphs.example'):
        raw=json.dumps(body).encode() if body is not None else b''
        env={'PATH_INFO':path,'REQUEST_METHOD':'POST' if body is not None else 'GET','HTTP_HOST':host,'HTTP_ORIGIN':origin,'HTTP_COOKIE':cookie,'CONTENT_TYPE':'application/json','CONTENT_LENGTH':str(len(raw)),'wsgi.input':io.BytesIO(raw)}
        reply={}
        def start(status,headers):reply.update(status=int(status.split()[0]),headers=dict(headers))
        raw=b''.join(self.app(env,start))
        reply['body']=json.loads(raw) if reply['headers']['Content-Type'].startswith('application/json') else raw.decode()
        reply['cookie']=reply['headers'].get('Set-Cookie',cookie).split(';')[0]
        return reply
    def test_graph_isolation(self):
        a=self.call('/api/graph');b=self.call('/api/graph')
        self.assertNotEqual(a['cookie'],b['cookie'])
        self.assertEqual(self.call('/api/graph',{'nodes':2,'edges':[[1,2]]},a['cookie'])['status'],201)
        self.assertEqual(self.call('/api/graph',cookie=b['cookie'])['body'],b['body'])
    def test_shared_key_private_and_immutable(self):
        a=self.call('/api/model');b=self.call('/api/model')
        for r in (a,b):
            self.assertTrue(r['body']['configured']);self.assertTrue(r['body']['shared']);self.assertNotIn('owner-test-secret',str(r))
        for path in ('/api/model','/api/model/clear','/api/model/test'):
            self.assertEqual(self.call(path,{},a['cookie'])['status'],403)
        def fake_plan(*args):
            self.assertEqual(model_config.current()['api_key'],'owner-test-secret')
            return {'tool':'clarify','arguments':{'question':'test'}},{}
        with patch('app.plan',fake_plan):
            for cookie in (a['cookie'],b['cookie']):self.assertEqual(self.call('/api/query',{'text':'test','mode':'llm'},cookie)['status'],200)
        self.assertIsNone(model_config.visitor_settings.get())
        self.assertNotIn('owner-test-secret',self.call('/')['body'])
    def test_origin_host_and_cookie(self):
        a=self.call('/api/graph')
        self.assertEqual(self.call('/api/query',{},a['cookie'],origin='https://other.example')['status'],403)
        self.assertEqual(self.call('/api/graph',host='attacker.example')['status'],403)
        self.assertIn('HttpOnly',a['headers']['Set-Cookie']);self.assertIn('Secure',a['headers']['Set-Cookie'])
    def test_demo_query(self):
        a=self.call('/api/graph');r=self.call('/api/query',{'text':'from 1 to 1','mode':'demo'},a['cookie'])
        self.assertEqual(r['status'],200);self.assertEqual(r['body']['path'],[1])
    def test_global_model_limit(self):
        self.app.model_limit=1;self.app.reserve_model_call()
        self.assertEqual(self.call('/api/query',{'text':'test','mode':'llm'})['status'],429)
        self.assertEqual(self.call('/api/query',{'text':'from 1 to 1','mode':'demo'})['status'],200)
    def test_session_expiry(self):
        a=self.call('/api/graph');old=a['cookie'].split('=')[1];self.app.sessions[old]['expires']=0
        self.assertNotEqual(a['cookie'],self.call('/api/graph',cookie=a['cookie'])['cookie']);self.assertNotIn(old,self.app.sessions)

class HostedWalkingTests(HostedTests):
    def test_walk_page_and_isolation(self):
        a=self.call('/api/walk');b=self.call('/api/walk')
        self.assertEqual(a['status'],200);self.assertEqual(self.call('/walk')['status'],200)
        r=self.call('/api/walk',{'action':'confirm_limit','minutes':5,'revision':0},a['cookie'])
        self.assertEqual(r['body']['max_extra_minutes'],5)
        self.assertIsNone(self.call('/api/walk',cookie=b['cookie'])['body']['max_extra_minutes'])
    def test_tile_errors_are_json(self):
        r=self.call('/api/walk/tile/0/0/0.png')
        self.assertEqual(r['status'],400);self.assertIn('error',r['body'])
