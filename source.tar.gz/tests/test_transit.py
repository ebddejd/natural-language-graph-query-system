import unittest
from unittest.mock import patch
from datetime import datetime,timedelta
from transit import Dataset,TransitPlanner,TZ,seconds,departure,now_local
from navigation import NavigationSession
from core import Error
from walking import distance

class Walk:
    def __init__(self):self.calls=[];self.block=False
    def route(self,pts,**kwargs):
        self.calls.append((pts,kwargs));coords=[[p['lon'],p['lat']] for p in pts]
        if self.block and pts[0].get('id')=='b' and pts[1].get('id')=='c':raise Error('No pedestrian access')
        m=distance(*coords)
        return {'geometry':{'type':'LineString','coordinates':coords},'distance_m':m,'duration_s':m/1.2,'steps':['Walk on the public path.']}

def fixture():
    d=Dataset.__new__(Dataset);day=now_local().strftime('%Y%m%d')
    d.stops={k:{'id':k,'code':k,'name':'Stop '+k,'lon':x,'lat':43.47} for k,x in [('a',-80.55),('b',-80.53),('c',-80.529),('d',-80.50)]}
    d.services={'bus:':{day:{'service'}}};d.ranges={'bus:':(day,day)};d.shapes={};d.neighbors={'a':[],'b':[('c',210)],'c':[],'d':[]}
    def trip(id,route,stops):return {'id':id,'prefix':'bus:','service':'service','route':route,'name':'Route '+route,'headsign':'East','vehicle':'Bus','shape':'','times':[(i,s,seconds(t),seconds(t),True,True) for i,(s,t) in enumerate(stops)]}
    d.trips={'one':trip('one','7',[('a','12:05:00'),('b','12:15:00')]),'two':trip('two','12',[('c','12:20:00'),('d','12:30:00')])}
    return d

class TransitTests(unittest.TestCase):
    def setUp(self):self.ds=fixture();self.provider=Walk();self.planner=TransitPlanner(self.provider,self.ds);self.when=now_local().strftime('%Y-%m-%d')+'T12:00'
    def test_direct_and_transfer_itinerary(self):
        routes=self.planner.plan(self.ds.stops['a'],self.ds.stops['d'],self.when);r=routes[0]
        rides=[l for l in r['legs'] if l['kind']=='ride']
        self.assertEqual([l['route'] for l in rides],['7','12']);self.assertEqual(r['transfers'],1)
        self.assertEqual(rides[0]['board']['name'],'Stop a');self.assertEqual(rides[0]['alight']['name'],'Stop b')
        self.assertEqual(rides[1]['board']['name'],'Stop c');self.assertIn('12:20',rides[1]['departure'])
        self.assertTrue(any(l['purpose']=='transfer' for l in r['legs'] if l['kind']=='walk'))
        self.assertTrue(all(l.get('geometry') for l in r['legs']))
    def test_invalid_transfer_is_not_returned(self):
        self.provider.block=True
        with self.assertRaises(Error):self.planner.plan(self.ds.stops['a'],self.ds.stops['d'],self.when)
    def test_actual_transfer_time_rechecks_connection(self):
        original=self.provider.route
        def slow(points,**kw):
            r=original(points,**kw)
            if points[0].get('id')=='b' and points[1].get('id')=='c':r['duration_s']=600
            return r
        self.provider.route=slow
        with self.assertRaises(Error):self.planner.plan(self.ds.stops['a'],self.ds.stops['d'],self.when)
    def test_pickup_restrictions(self):
        self.ds.trips['one']['times'][0]=(0,'a',43500,43500,False,True)
        with self.assertRaises(Error):self.planner.plan(self.ds.stops['a'],self.ds.stops['d'],self.when)
    def test_expired_service_is_not_used(self):
        self.ds.ranges={'bus:':('20200101','20200131')}
        with self.assertRaises(Error):self.planner.plan(self.ds.stops['a'],self.ds.stops['d'],self.when)
    def test_previous_service_day_after_midnight(self):
        start=now_local().replace(hour=0,minute=5,second=0,microsecond=0);yesterday=(start-timedelta(days=1)).strftime('%Y%m%d')
        self.ds.services={'bus:':{yesterday:{'service'}}}
        self.ds.trips['one']['times']=[(0,'a',seconds('24:10:00'),seconds('24:10:00'),True,True),(1,'b',seconds('24:20:00'),seconds('24:20:00'),True,True)]
        runs=self.ds.runs(start);self.assertEqual(len(runs),1);t,base=runs[0]
        self.assertEqual(datetime.fromtimestamp(base+t['times'][0][3],TZ).hour,0)
    def test_departure_validation(self):
        for value in ['not-a-date','2020-01-01T12:00','2026-10-30T12:00Z']:
            with self.assertRaises(Error):departure(value)
    def test_navigation_uses_local_planner_and_no_external_fallback(self):
        s=NavigationSession(self.provider);s.state={'mode':'transit','origin':self.ds.stops['a'],'destination':self.ds.stops['d']}
        expected=self.planner.plan(self.ds.stops['a'],self.ds.stops['d'],self.when)
        with patch('navigation.TransitPlanner.plan',return_value=expected):r=s.handle({'action':'plan','revision':0})
        self.assertTrue(r['routes'][0]['transit']);self.assertNotIn('Google',r['message'])
