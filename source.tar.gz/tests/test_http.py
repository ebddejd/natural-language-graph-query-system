import json, os, threading, unittest, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch
import app
from planner import plan
from core import Error

class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.old=app.service; app.service=app.Service()
        self.server=app.BoundedHTTPServer(('127.0.0.1',0),app.Handler)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.url=f'http://127.0.0.1:{self.server.server_port}'
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join();app.service=self.old
    def request(self,path,body=None,origin=None):
        headers={'Content-Type':'application/json'}
        if origin:headers['Origin']=origin
        req=urllib.request.Request(self.url+path,data=None if body is None else body.encode(),headers=headers)
        try:r=urllib.request.urlopen(req)
        except urllib.error.HTTPError as e:r=e
        with r:return r.status,json.load(r)
    def test_routes_and_atomic_update(self):
        code,g=self.request('/api/graph');self.assertEqual(code,200)
        code,r=self.request('/api/query',json.dumps({'text':'from 1 to 6','mode':'demo'}));self.assertEqual(code,200);self.assertEqual(r['hops'],3)
        self.assertEqual(self.request('/api/graph','{"nodes":2,"edges":[[1,3]]}')[0],400)
        self.assertEqual(self.request('/api/graph')[1],g)
        self.assertEqual(self.request('/api/graph','{"nodes":2,"edges":[[1,2]]}')[0],201)
        self.assertEqual(self.request('/api/graph?version=1')[1],g)
    def test_http_capacity_recovers(self):
        for _ in range(48):self.server.http_slots.acquire()
        try:self.assertEqual(self.request('/api/health')[0],503)
        finally:
            for _ in range(48):self.server.http_slots.release()
        self.assertEqual(self.request('/api/health')[0],200)
    def test_bad_requests(self):
        self.assertEqual(self.request('/api/query','{')[0],400)
        self.assertEqual(self.request('/api/query','{}','https://foreign.example')[0],403)
        with patch.dict(os.environ,{},clear=True):
            self.assertEqual(self.request('/api/query','{"mode":"llm","text":"from 1 to 6"}')[0],503)

class ProviderTests(unittest.TestCase):
    def test_local_provider_transport(self):
        captured=[]
        class Provider(BaseHTTPRequestHandler):
            def do_POST(self):
                captured.append((self.path,json.loads(self.rfile.read(int(self.headers['Content-Length'])))))
                if len(captured)==2:
                    self.send_response(500);self.end_headers();return
                raw=json.dumps({'choices':[{'message':{'tool_calls':[{'function':{'name':'query_graph','arguments':json.dumps({'source':1,'target':6,'operation':'shortest_path','avoid_nodes':[],'avoid_edges':[]})}}]}}],'usage':{'total_tokens':42}}).encode()
                self.send_response(200);self.end_headers();self.wfile.write(raw)
            def log_message(self,*args):pass
        server=ThreadingHTTPServer(('127.0.0.1',0),Provider)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            with patch.dict(os.environ,{'LLM_API_KEY':'test-only','LLM_MODEL':'fake','LLM_BASE_URL':f'http://127.0.0.1:{server.server_port}/v1'}):
                call,usage=plan('from 1 to 6','llm',app.service.store.get())
                self.assertEqual(call['arguments']['target'],6);self.assertEqual(usage['total_tokens'],42)
                self.assertEqual(captured[0][0],'/v1/chat/completions');self.assertFalse(captured[0][1]['parallel_tool_calls'])
                with self.assertRaises(Error) as cm:plan('from 1 to 6','llm',app.service.store.get())
                self.assertEqual(cm.exception.status,502)
        finally:server.shutdown();server.server_close();thread.join()
