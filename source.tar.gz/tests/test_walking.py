import unittest
from unittest.mock import patch
from walking import WalkSession, GeoProvider, Error, inside
P={'id':'p','name':'Library','address':'Waterloo','lon':-80.53,'lat':43.47}
def route(seconds):return {'distance_m':seconds,'duration_s':seconds,'geometry':{'type':'LineString','coordinates':[[-80.53,43.47],[-80.54,43.48]]},'steps':['Walk north']}
class FakeGeo:
    def geocode(self,text):return [dict(P,id=text,name=text)]
    def route(self,points):return route(600 if len(points)==2 else 900 if points[1]['id']=='near' else 1500)
    def cafes(self,r):return [dict(P,id='far',name='Far cafe'),dict(P,id='near',name='Near cafe')]
class WalkTests(unittest.TestCase):
    def setUp(self):self.s=WalkSession(FakeGeo())
    def send(self,**b):return self.s.handle(dict(b,revision=self.s.revision))
    def ready(self,limit=10):self.s.state.update(origin=P,destination=dict(P,id='school'),max_extra_minutes=limit)
    def test_confirmation_and_ranking(self):
        a=dict(origin='Library',destination='University',max_extra_minutes=10,different_cafe=False,question=None)
        with patch('walking.interpret',return_value=(a,{})):r=self.send(action='message',text='walk')
        self.assertEqual(r['pending']['field'],'origin');self.assertIsNone(r['baseline'])
        r=self.send(action='choose_place',id='Library');self.assertEqual(r['pending']['field'],'destination')
        r=self.send(action='choose_place',id='University');self.assertEqual(len(r['candidates']),1)
        self.assertEqual(r['candidates'][0]['place']['id'],'near');self.assertEqual(r['candidates'][0]['extra_s'],300)
        self.assertIsNone(r['selected']);r=self.send(action='select',id=r['candidates'][0]['id']);self.assertEqual(r['selected']['place']['id'],'near')
    def test_limit_requires_confirmation(self):
        self.ready(None);r=self.send(action='retry');self.assertEqual(r['pending']['kind'],'limit');self.assertIsNone(r['baseline'])
    def test_zero_limit_never_relaxed(self):
        self.ready(0);r=self.send(action='retry');self.assertEqual(r['candidates'],[]);self.assertEqual(r['max_extra_minutes'],0)
    def test_stale_revision_and_ids(self):
        self.ready();self.send(action='retry')
        with self.assertRaises(Error):self.s.handle({'action':'reset','revision':0})
        with self.assertRaises(Error):self.send(action='select',id='invented')
    def test_failed_provider_rolls_back(self):
        self.ready();old=dict(self.s.state)
        with patch.object(self.s.provider,'cafes',side_effect=Error('offline',502)):
            with self.assertRaises(Error):self.send(action='retry')
        self.assertEqual(self.s.state,old);self.assertEqual(self.s.revision,0)
    def test_change_invalidates_selection(self):
        self.ready();r=self.send(action='retry');self.send(action='select',id=r['candidates'][0]['id'])
        a=dict(origin=None,destination=None,max_extra_minutes=0,different_cafe=False,question=None)
        with patch('walking.interpret',return_value=(a,{})):r=self.send(action='message',text='no detour')
        self.assertIsNone(r['selected']);self.assertEqual(r['candidates'],[])
    def test_different_preserves_endpoints(self):
        self.ready();r=self.send(action='retry');self.send(action='select',id=r['candidates'][0]['id'])
        a=dict(origin=None,destination=None,max_extra_minutes=None,different_cafe=True,question=None)
        with patch('walking.interpret',return_value=(a,{})):r=self.send(action='message',text='another')
        self.assertEqual(r['origin'],P);self.assertEqual(r['candidates'],[])
    def test_session_independence(self):
        self.ready();other=WalkSession(FakeGeo());self.assertIsNone(other.public()['origin'])
    def test_region_and_tiles(self):
        self.assertTrue(inside(-80.53,43.47));self.assertFalse(inside(-79.38,43.65))
        with self.assertRaises(Error):GeoProvider().tile(18,1,1)
