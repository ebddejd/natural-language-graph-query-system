import unittest
from unittest.mock import patch
from navigation import NavigationSession,distinct,Error
P={'id':'p','name':'Library','lon':-80.53,'lat':43.47}
def route(coords,meters):return {'geometry':{'type':'LineString','coordinates':coords},'distance_m':meters,'duration_s':meters,'steps':['Walk']}
BASE=route([[-80.53,43.47],[-80.535,43.475],[-80.54,43.48]],1000)
ALT=route([[-80.53,43.47],[-80.54,43.47],[-80.54,43.48]],1300)
class Geo:
    def route(self,pts,route_type='short',avoid=None,mode='walk'):return dict(ALT if route_type=='balanced' else BASE)
    def geocode(self,text):return [dict(P,id=text,name=text)]
class NavTests(unittest.TestCase):
    def setUp(self):self.s=NavigationSession(Geo())
    def call(self,**b):return self.s.handle(dict(b,revision=self.s.revision))
    def ready(self):
        self.call(action='point',field='origin',lon=-80.53,lat=43.47)
        return self.call(action='point',field='destination',lon=-80.54,lat=43.48)
    def test_points_generate_deduped_sorted_routes(self):
        r=self.ready();self.assertEqual(len(r['routes']),2);self.assertEqual(r['routes'][0]['distance_m'],1000);self.assertEqual(r['selected'],r['routes'][0]['id'])
        r=self.call(action='select',id=r['routes'][1]['id']);self.assertEqual(r['selected'],r['routes'][1]['id'])
    def test_invalid_points_and_selection(self):
        for lon,lat in [(float('nan'),43.47),(-79,43.47),(-80.53,91)]:
            with self.assertRaises(Error):self.call(action='point',field='origin',lon=lon,lat=lat)
        with self.assertRaises(Error):self.call(action='select',id='fake')
    def test_move_invalidates_old_route(self):
        r=self.ready();old=r['selected'];r=self.call(action='point',field='origin',lon=-80.531,lat=43.471)
        self.assertNotEqual(old,r['selected'])
    def test_duplicates_are_not_alternatives(self):self.assertFalse(distinct(BASE,[BASE]));self.assertTrue(distinct(ALT,[BASE]))
    def test_search_confirmation_and_natural_language(self):
        with patch('navigation.intent',return_value={'origin':'Library','destination':'University','question':None}):r=self.call(action='message',text='from library to university')
        self.assertEqual(r['pending']['field'],'origin');r=self.call(action='choose',id='Library');self.assertEqual(r['pending']['field'],'destination')
    def test_failure_restores_state(self):
        self.call(action='point',field='origin',lon=-80.53,lat=43.47)
        with patch.object(self.s.provider,'route',side_effect=Error('offline',502)):
            with self.assertRaises(Error):self.call(action='point',field='destination',lon=-80.54,lat=43.48)
        self.assertIsNone(self.s.public()['destination'])
    def test_swap_and_reset(self):
        self.ready();r=self.call(action='swap');self.assertEqual(r['origin']['lon'],-80.54)
        r=self.call(action='reset');self.assertIsNone(r['routes']);self.assertIsNone(r['origin'])

class ModeTests(NavTests):
    def test_mode_is_forwarded_and_invalidated(self):
        old=self.ready()['selected']
        with patch.object(self.s.provider,'route',wraps=self.s.provider.route) as route_mock:
            r=self.call(action='mode',mode='drive')
            self.assertEqual(r['mode'],'drive');self.assertNotEqual(r['selected'],old)
            self.assertTrue(all(c.kwargs['mode']=='drive' for c in route_mock.call_args_list))
        with self.assertRaises(Error):self.call(action='mode',mode='bus')
    def test_transit_unavailable_does_not_show_previous_driving_route(self):
        self.ready()
        with patch.object(self.s.provider,'route',side_effect=Error('No coverage',422)):
            r=self.call(action='mode',mode='transit')
        self.assertEqual(r['mode'],'transit');self.assertEqual(r['routes'],[]);self.assertIn('unavailable',r['message'])
    def test_location_label_and_bounds(self):
        r=self.call(action='point',field='origin',lat=43.47,lon=-80.53,current_location=True)
        self.assertTrue(r['origin']['name'].startswith('Current location'))
        with self.assertRaises(Error):self.call(action='point',field='origin',lat=45,lon=-80,current_location=True)
