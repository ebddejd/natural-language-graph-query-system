import unittest,threading,time,contextlib,io
from unittest.mock import patch
from app import Service
from core import Error
from planner import demo
from runtime import Admission,Metrics,percentile
class RuntimeTests(unittest.TestCase):
    def test_fifo_capacity_timeout_recovery(self):
        a=Admission(1,2,.2);a.enter();order=[]
        def run(n):a.enter();order.append(n);a.leave()
        threads=[]
        for n in [1,2]:
            t=threading.Thread(target=run,args=(n,));threads.append(t);t.start()
            deadline=time.monotonic()+1
            while a.state()['waiting']<n and time.monotonic()<deadline:time.sleep(.001)
        with self.assertRaises(Error) as c:a.enter()
        self.assertEqual(c.exception.code,'queue_full');a.leave()
        for t in threads:t.join(1)
        self.assertEqual(order,[1,2]);self.assertEqual(a.state()['active'],0)
        a=Admission(1,1,.01);a.enter()
        with self.assertRaises(Error) as c:a.enter()
        self.assertEqual(c.exception.code,'queue_timeout');a.leave();a.enter();a.leave()
        self.assertEqual(a.state()['waiting'],0)
    def test_failure_records_and_releases(self):
        s=Service(active=1);args={'mode':'llm','text':'private prompt'}
        with contextlib.redirect_stdout(io.StringIO()) as log,patch('app.plan',side_effect=Error('sensitive provider detail',504,'model_timeout')):
            with self.assertRaises(Error):s.query(args)
        self.assertNotIn('private prompt',log.getvalue());self.assertNotIn('sensitive provider detail',log.getvalue())
        self.assertEqual(s.admission.state()['active'],0)
        self.assertEqual(s.metrics.snapshot()['counters_since_start']['model_timeout'],1)
        with contextlib.redirect_stdout(io.StringIO()):self.assertTrue(s.query({'mode':'demo','text':'from 1 to 6'})['reachable'])
    def test_metrics_window_and_percentile(self):
        m=Metrics(3)
        for i in range(6):m.record({'mode':'demo','http_status':200,'total_ms':i})
        data=m.snapshot();self.assertEqual(data['rolling_samples'],3);self.assertEqual(data['counters_since_start']['requests'],6)
        self.assertEqual(percentile(range(1,101),.95),95)
