import json, time, threading, uuid, os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from core import Store, Engine, Error, ROOT
from planner import plan
from generation import generate
import model_config
from runtime import Admission,Metrics
SAMPLE={'streets':{'King Street':[[1,2],[2,4]],'University Avenue':[[3,7],[7,6]],'Columbia Street':[[1,3],[3,4],[4,5],[5,6]]},'nodes':8,'edges':[[1,2],[1,3],[2,4],[3,4],[4,5],[5,6],[3,7],[7,6]]}
class Service:
    def __init__(self,initial=None,active=4,waiting=16,queue_timeout=2):
        self.store=Store();self.store.publish(SAMPLE if initial is None else initial);self.engine=Engine()
        self.admission=Admission(active,waiting,queue_timeout);self.metrics=Metrics()
    def query(self,body):
        start=time.perf_counter();rid=uuid.uuid4().hex[:12];admitted=False;stage=None;stage_start=start
        mode=body.get('mode','llm') if isinstance(body,dict) else 'unknown'
        row={'request_id':rid,'mode':mode if mode in ('llm','demo','structured') else 'unknown','http_status':500}
        try:
            if not isinstance(body,dict):raise Error('Expected JSON object')
            snap=self.store.get(body.get('graph_version'));row['graph_version']=snap.version
            stage='admission_ms';stage_start=time.perf_counter()
            row[stage]=round(self.admission.enter(),3);admitted=True;stage=None
            usage={};stage='planning_ms';stage_start=time.perf_counter()
            if mode=='structured':call={'tool':'query_graph','arguments':body.get('arguments')}
            else:
                text=body.get('text')
                if not isinstance(text,str) or not 1<=len(text)<=4000:raise Error('Text must be 1–4000 characters')
                call,usage=plan(text,mode,snap)
            row[stage]=round((time.perf_counter()-stage_start)*1000,3);stage=None
            if mode=='llm':row['model_ms']=row['planning_ms']
            if call['tool']=='clarify':result={'status':'clarification','answer':call['arguments']['question'],'graph_version':snap.version}
            else:
                stage='engine_total_ms';stage_start=time.perf_counter()
                result=self.engine.execute(snap,call['arguments'])
                row[stage]=round((time.perf_counter()-stage_start)*1000,3);stage=None
                row['worker_queue_ms']=result['queue_ms'];row['worker_ms']=result['worker_ms']
                if result.get('graph_compute_ms') is not None:row['graph_compute_ms']=result['graph_compute_ms']
                result['status']='ok'
                result['answer']=(' → '.join(map(str,result['path']))+f" ({result['hops']} hops)") if result['reachable'] else 'No path exists under these constraints.'
            row['http_status']=200
            result.update(request_id=rid,mode=mode,tool_call=call,usage=usage,planning_ms=row['planning_ms'],admission_ms=row['admission_ms'],total_ms=round((time.perf_counter()-start)*1000,3))
            return result
        except Error as e:
            row.update(http_status=e.status,error_code=e.code);e.request_id=rid;raise
        except Exception:
            row.update(http_status=500,error_code='internal_error');raise
        finally:
            if stage:row[stage]=round((time.perf_counter()-stage_start)*1000,3)
            if mode=='llm' and 'planning_ms' in row:row['model_ms']=row['planning_ms']
            row['total_ms']=round((time.perf_counter()-start)*1000,3)
            if admitted:self.admission.leave()
            self.metrics.record(row)
            print(json.dumps(row),flush=True) # Whitelist-only logs: never prompt, key, or provider body.

service=Service(json.loads((ROOT/'data/initial-graph.json').read_text()))
class BoundedHTTPServer(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.http_slots=threading.BoundedSemaphore(48)
    def process_request(self,request,address):
        if not self.http_slots.acquire(blocking=False):
            try:
                request.settimeout(.1);body=b'{"error":"HTTP capacity exhausted","code":"http_overload"}'
                request.sendall(b'HTTP/1.1 503 Service Unavailable\r\nContent-Type: application/json\r\nContent-Length: '+str(len(body)).encode()+b'\r\nConnection: close\r\n\r\n'+body)
            except OSError:pass
            finally:self.shutdown_request(request)
            return
        try:super().process_request(request,address)
        except Exception:self.http_slots.release();raise
    def process_request_thread(self,*args):
        try:super().process_request_thread(*args)
        finally:self.http_slots.release()
class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup();self.connection.settimeout(10)

    def send(self,status,data,ctype='application/json'):
        raw=json.dumps(data,ensure_ascii=False).encode() if ctype=='application/json' else data
        self.send_response(status)
        if isinstance(data,dict) and data.get('request_id'):self.send_header('X-Request-ID',data['request_id'])
        if status==503:self.send_header('Retry-After','1')
        self.send_header('Content-Type',ctype+'; charset=utf-8')
        self.send_header('Content-Length',str(len(raw))); self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(raw)
    def local_host(self):
        if urlparse('http://'+self.headers.get('Host','')).hostname not in ('localhost','127.0.0.1','::1'):raise Error('Local host required',403)
    def do_GET(self):
        path=urlparse(self.path)
        try:
            self.local_host()
            if path.path=='/': return self.send(200,(ROOT/'web/index.html').read_bytes(),'text/html')
            if path.path=='/api/health':return self.send(200,{'status':'ok','llm_configured':model_config.public()['configured']})
            if path.path=='/api/metrics':return self.send(200,dict(service.metrics.snapshot(),admission=service.admission.state()))
            if path.path=='/api/model':return self.send(200,model_config.public())
            if path.path=='/api/graph':
                v=parse_qs(path.query).get('version',[None])[0]
                return self.send(200,service.store.get(int(v) if v is not None else None).public())
            raise Error('Not found',404)
        except (Error,ValueError) as e:self.send(getattr(e,'status',400),{'error':str(e),'code':getattr(e,'code','invalid_request'),'request_id':getattr(e,'request_id',None)})
    def do_POST(self):
        try:
            self.local_host()
            # Local-only app: reject browser requests originating from other sites.
            origin=self.headers.get('Origin')
            if origin and origin!=f'http://{self.headers.get("Host")}':raise Error('Cross-origin request denied',403)
            if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise Error('Use application/json',415)
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=2_000_000:raise Error('Invalid body size',413)
            body=json.loads(self.rfile.read(size))
            if self.path=='/api/model':return self.send(200,model_config.configure(body))
            if self.path=='/api/model/test':
                result=service.query({'mode':'llm','text':'Find the shortest path from node 1 to node 1. No exclusions.'})
                if result['status']!='ok' or result.get('path')!=[1]:raise Error('Model connection responded but failed the tool-call test',502)
                return self.send(200,{'verified':True,'message':'真实模型工具调用测试通过','usage':result.get('usage',{})})
            if self.path=='/api/graph/generate':return self.send(201,service.store.publish(generate(body)).public())
            if self.path=='/api/graph':return self.send(201,service.store.publish(body).public())
            if self.path=='/api/query':return self.send(200,service.query(body))
            raise Error('Not found',404)
        except (Error,ValueError,TypeError) as e:self.send(getattr(e,'status',400),{'error':str(e),'code':getattr(e,'code','invalid_request'),'request_id':getattr(e,'request_id',None)})
        except Exception:self.send(500,{'error':'Internal server error'})
    def log_message(self,*args):pass
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765);args=p.parse_args()
    try:service=Service(generate({'streets':8,'segments':3,'coord':20}))
    except Error:pass  # Bundled fallback also uses A3 intersections.
    print(f'Open http://127.0.0.1:{args.port}',flush=True)
    BoundedHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
