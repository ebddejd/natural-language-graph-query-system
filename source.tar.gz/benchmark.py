"""Repeatable local structured and simulated-AI workload benchmark."""
import contextlib,io,json,time,argparse
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
from app import Service
from planner import demo
from core import Error,ROOT
from runtime import percentile

def main():
    p=argparse.ArgumentParser();p.add_argument('--requests',type=int,default=100);args=p.parse_args()
    if args.requests<1:p.error('requests must be positive')
    reports=[]
    def simulated(*args):time.sleep(.03);return demo('from 1 to 6'),{}
    for workload in ['structured','simulated_model_30ms']:
        for concurrency in [1,4,8,16,32]:
            s=Service()
            def run(i):
                start=time.perf_counter()
                try:
                    r=s.query({'mode':'structured','arguments':{'source':1,'target':6}} if workload=='structured' else {'mode':'llm','text':'from 1 to 6'})
                    return {'status':200,'ms':(time.perf_counter()-start)*1000}
                except Error as e:return {'status':e.status,'code':e.code,'ms':(time.perf_counter()-start)*1000}
            with patch('app.plan',side_effect=simulated),contextlib.redirect_stdout(io.StringIO()):
                start=time.perf_counter()
                with ThreadPoolExecutor(max_workers=concurrency) as pool:rows=list(pool.map(run,range(args.requests)))
                elapsed=time.perf_counter()-start
            ok=[r['ms'] for r in rows if r['status']==200]
            reports.append({'workload':workload,'concurrency':concurrency,'requests':args.requests,'successes':len(ok),'errors':len(rows)-len(ok),'successful_requests_per_s':round(len(ok)/elapsed,2),'success_p95_ms':percentile(ok,.95),'all_outcomes_p95_ms':percentile([r['ms'] for r in rows],.95),'metrics':s.metrics.snapshot()['by_mode']})
    report={'scope':'In-process service + real C++ workers. Simulated model has fixed 30 ms sleep, NOT real model latency. HTTP transport excluded. Failed requests separated from successful latency.','runs':reports}
    (ROOT/'reports/concurrency.json').write_text(json.dumps(report,indent=2));print(json.dumps([{k:v for k,v in r.items() if k!='metrics'} for r in reports],indent=2))
if __name__=='__main__':main()
