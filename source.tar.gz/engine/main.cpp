#include "graph.h"
#include <iostream>
#include <chrono>
// One validated snapshot and query per process. OS pipes isolate worker failures.
int main() {
    try {
        int n,m,s,t;
        if (!(std::cin>>n>>m>>s>>t) || n<1 || n>10002 || m<0 || m>70000)
            return 2;
        std::vector<std::pair<int,int>> edges;
        for(int i=0,a,b;i<m;i++) {
            if (!(std::cin>>a>>b)) return 2;
            edges.emplace_back(a,b);
        }
        Graph g; g.set_vertices(n); g.set_edges(edges);
        auto compute_start=std::chrono::steady_clock::now();
        try {
            auto path=g.shortest_path(s,t);
            for(auto v:path) std::cout<<v<<' ';
            std::cout<<'\n';
        } catch(const std::invalid_argument&) { std::cout<<"NONE\n"; }
        std::cerr << "compute_ms " << std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-compute_start).count() << "\n";
    } catch(const std::exception& e) { std::cerr<<e.what(); return 2; }
}
