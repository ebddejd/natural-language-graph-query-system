#include "graph.h"

#include <algorithm>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <string>

bool Graph::valid(int vertex) const {
    return vertex >= 1 && static_cast<std::size_t>(vertex) < neighbours.size();
}

void Graph::set_vertices(int count) {
    if (count < 0) {
        throw std::invalid_argument("vertex count must not be negative.");
    }
    neighbours.assign(static_cast<std::size_t>(count) + 1, std::vector<int>());
    ready = false;
}

void Graph::set_edges(const std::vector<std::pair<int, int>>& edges) {
    if (neighbours.empty()) {
        throw std::invalid_argument("specify V before E.");
    }
    // Build separately so an invalid edge cannot leave a partial graph.
    std::vector<std::vector<int>> new_neighbours(neighbours.size());
    for (const auto& edge : edges) {
        int a = edge.first;
        int b = edge.second;
        if (!valid(a) || !valid(b)) {
            throw std::invalid_argument("edge vertex is outside the range 1..V.");
        }
        new_neighbours[a].push_back(b);
        new_neighbours[b].push_back(a);
    }
    neighbours.swap(new_neighbours);
    ready = true;
}

std::vector<int> Graph::shortest_path(int start, int finish) const {
    if (!ready) {
        throw std::invalid_argument("specify a valid V and E before a query.");
    }
    if (!valid(start) || !valid(finish)) {
        throw std::invalid_argument("query vertex is outside the range 1..V.");
    }

    // parent also tracks visits: -1 means not yet discovered.
    std::vector<int> parent(neighbours.size(), -1);
    std::queue<int> waiting;
    parent[start] = start;
    waiting.push(start);

    while (!waiting.empty() && parent[finish] == -1) {
        int current = waiting.front();
        waiting.pop();
        for (int neighbour : neighbours[current]) {
            if (parent[neighbour] == -1) {
                parent[neighbour] = current;
                waiting.push(neighbour);
            }
        }
    }

    if (parent[finish] == -1) {
        throw std::invalid_argument("no path exists between these vertices.");
    }
    std::vector<int> path;
    int current = finish;
    while (current != start) {
        path.push_back(current);
        current = parent[current];
    }
    path.push_back(start);
    std::reverse(path.begin(), path.end());
    return path;
}

namespace {
// Small parsing helpers keep the command loop readable.
void expect(std::istream& input, char wanted) {
    char found;
    if (!(input >> found) || found != wanted) {
        throw std::invalid_argument("invalid command format.");
    }
}

int read_number(std::istream& input) {
    int number;
    if (!(input >> number)) {
        throw std::invalid_argument("expected an integer in range.");
    }
    return number;
}

void check_end(std::istream& input) {
    input >> std::ws;
    if (!input.eof()) {
        throw std::invalid_argument("unexpected text after command.");
    }
}

std::vector<std::pair<int, int>> read_edges(std::istream& input) {
    std::vector<std::pair<int, int>> edges;
    expect(input, '{');
    input >> std::ws;
    if (input.peek() != '}') {
        while (true) {
            expect(input, '<');
            int a = read_number(input);
            expect(input, ',');
            int b = read_number(input);
            expect(input, '>');
            edges.push_back(std::make_pair(a, b));
            input >> std::ws;
            if (input.peek() == '}') {
                break;
            }
            expect(input, ',');
        }
    }
    expect(input, '}');
    check_end(input);
    return edges;
}
} // namespace

bool Commands::accept(const std::string& line, std::ostream& output, std::ostream& errors) {
    try {
        std::istringstream row(line);
        char command;
        if (!(row >> command)) return true;
        if (command == 'V') {
            int value = read_number(row);
            check_end(row);
            graph.set_vertices(value);
            count = value;
        } else if (command == 'E') {
            auto edges = read_edges(row);
            graph.set_edges(edges);
            output << "V " << count << "\nE {";
            for (std::size_t i = 0; i < edges.size(); ++i) {
                if (i) output << ',';
                output << '<' << edges[i].first << ',' << edges[i].second << '>';
            }
            output << "}" << std::endl;
        } else if (command == 's') {
            int start = read_number(row);
            int finish = read_number(row);
            check_end(row);
            auto path = graph.shortest_path(start, finish);
            for (std::size_t i = 0; i < path.size(); ++i) {
                if (i) output << '-';
                output << path[i];
            }
            output << std::endl;
        } else {
            throw std::invalid_argument("unknown command.");
        }
        return true;
    } catch (const std::invalid_argument& error) {
        errors << "Error: " << error.what() << std::endl;
        return false;
    }
}

void run(std::istream& input, std::ostream& output, std::ostream& errors) {
    Commands commands;
    std::string line;
    while (std::getline(input, line)) commands.accept(line, output, errors);
}
