#ifndef GRAPH_H
#define GRAPH_H

#include <istream>
#include <ostream>
#include <utility>
#include <vector>
#include <string>

class Graph {
public:
    void set_vertices(int count);
    void set_edges(const std::vector<std::pair<int, int>>& edges);
    std::vector<int> shortest_path(int start, int finish) const;

private:
    // Index 0 is unused: the assignment numbers vertices from 1.
    std::vector<std::vector<int>> neighbours;
    bool ready = false;
    bool valid(int vertex) const;
};

// Shared command handling for standalone A2 and the IPC input loop.
class Commands {
public:
    bool accept(const std::string& line, std::ostream& output, std::ostream& errors);
private:
    Graph graph;
    int count = 0;
};

void run(std::istream& input, std::ostream& output, std::ostream& errors);

#endif
