# Render deployment

Prepared for a single Render Docker Web Service on the Free compute plan.

## Deploy

1. Put the contents of this project (not the enclosing workspace) in a private GitHub repository.
2. Connect that repository to Render → New → Web Service.
3. Select Docker, Free, and health check `/api/health`. Leave Docker Command blank.
4. Deploy. `RENDER_EXTERNAL_URL` and `PORT` are supplied by Render. For another host, set `PUBLIC_URL` to its exact HTTPS origin.
5. Open the assigned HTTPS URL and test graph generation, renaming, and a Demo query. In Render → Environment, set LLM_API_KEY to the owner’s OpenAI API key and LLM_MODEL to the model ID you use, then Save and deploy. Visitors automatically use this model; no key entry is needed on the site.

Alternatively use Render Blueprints with the included `render.yaml`.

Set the owner’s API key only through Render’s secret environment-variable UI, never in code, Git, chat, or render.yaml. LLM_API_KEY and LLM_MODEL are required for shared AI mode. LLM_REQUESTS_PER_MINUTE optionally controls the global limit (default 20). Do not upload .env, virtual environments, reports, or compiled macOS binaries. The Docker build compiles the copied C++ sources for Linux.

## Hosted behavior

- Waitress binds 0.0.0.0:$PORT; health checks do not allocate visitor sessions.
- HTTPS HttpOnly SameSite=Strict cookie identifies an independent in-memory visitor session.
- Graphs and metrics are isolated. All visitors use the owner’s read-only server model configuration. Model calls and workers share global bounded admission.
- Up to 128 sessions; idle sessions expire after 30 minutes and are removed on a subsequent request. No database persistence. Restart, redeploy, or free-tier sleep loses session state.
- 90 requests per minute per session; up to 500 nodes / 2000 edges and 8 graph snapshots per session. These are demo resource limits, not comprehensive DDoS protection.
- Hosted mode fixes the provider to https://api.openai.com/v1 and rejects all visitor model configuration/test/clear endpoints. The original local app still supports local models.
- The owner key is loaded from server environment variables and never returned or logged. Questions and street catalogs are sent to OpenAI in LLM mode. All visitors’ model usage is billed to the owner.
- Shared AI mode is selected automatically when the owner config exists. Missing configuration falls back to the clearly labelled fixed-grammar Demo. Global model request cap: 20/minute by default; this is not a dollar budget cap.
- This is a single-instance demo. Do not scale horizontally without external session storage and shared rate limits.

## Verification status

Shared-model tests cover owner-key use across sessions without leakage, blocked public configuration, global model rate limits, graph isolation, host/origin checks, and session expiry. The Waitress entry point was smoke-tested locally (health, geometry, demo query, model status). Docker/Linux image build and public HTTPS smoke tests must run during actual Render deployment; local Docker is unavailable.

## References

- https://render.com/docs/web-services
- https://render.com/docs/docker
- https://render.com/docs/free

Render Free services sleep after 15 minutes without traffic and can take about a minute to wake. Free-tier quotas apply; no paid compute plan has been selected or purchased.
