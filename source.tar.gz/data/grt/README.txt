GRT official scheduled transit snapshots (bus and ION).
Sources:
https://webapps.regionofwaterloo.ca/api/grt-routes/api/staticfeeds/1
https://webapps.regionofwaterloo.ca/api/grt-routes/api/staticfeeds/2
Source listing: https://www.grt.ca/about-grt/open-data/
Licence: Region of Waterloo Open Data Licence v2.0
https://regionofwaterloo-018-ca.govstack.com/government-and-council/transparency-and-accountability/open-data/
Contains information provided by the Regional Municipality of Waterloo under licence.
Independent project; not endorsed by GRT. Data supplied without warranty.
See metadata.json for download timestamp. The app attempts a bounded background
refresh once per day. It retains a validated snapshot if refresh fails and rejects
requests outside published service dates. No GTFS-Realtime data is used.
