"""Immutable graph snapshots, bounded subprocess execution, validated tools."""
import json, subprocess, threading, time
from dataclasses import dataclass
from pathlib import Path
ROOT=Path(__file__).resolve().parent
class Error(Exception):
    def __init__(self, message, status=400, code=None):
        super().__init__(message); self.status=status; self.code=code or ('invalid_request' if status==400 else 'service_error')

def integer(x, low, high):
    if type(x) is not int or not low<=x<=high: raise Error(f'Expected integer in [{low}, {high}]')
    return x

@dataclass(frozen=True)
class Snapshot:
    version:int
    n:int
    edges:tuple
    streets:tuple=()
    geometry_json:str=""
    def public(self): return {'version':self.version,'nodes':self.n,'edges':self.edges,'streets':{name:edges for name,edges in self.streets},**({'geometry':json.loads(self.geometry_json)} if self.geometry_json else {})}

class Store:
    def __init__(self): self.lock=threading.Lock(); self.history={}; self.current=0
    def publish(self, data):
        if not isinstance(data,dict): raise Error('Graph must be an object')
        n=integer(data.get('nodes'),1,10000); raw=data.get('edges')
        if not isinstance(raw,list) or len(raw)>50000: raise Error('Invalid edges list')
        edges=set()
        for e in raw:
            if not isinstance(e,list) or len(e)!=2: raise Error('Each edge must contain two vertices')
            a,b=(integer(v,1,n) for v in e)
            if a==b: raise Error('Self loops are not supported')
            edges.add(tuple(sorted((a,b))))
        raw_streets=data.get('streets',{})
        if not isinstance(raw_streets,dict) or len(raw_streets)>100:raise Error('Invalid streets mapping')
        streets=[]; names=set()
        for name,links in raw_streets.items():
            if not isinstance(name,str) or not name.strip() or len(name)>80 or name.strip().casefold() in names:raise Error('Street names must be unique, non-empty, at most 80 characters')
            names.add(name.strip().casefold())
            if not isinstance(links,list):raise Error('Street edges must be a list')
            member=set()
            for pair in links:
                if not isinstance(pair,list) or len(pair)!=2:raise Error('Invalid street edge')
                edge=tuple(sorted(integer(v,1,n) for v in pair))
                if edge not in edges:raise Error('Street edge is not in graph')
                member.add(edge)
            streets.append((name.strip(),tuple(sorted(member))))
        geometry_json=''
        if 'geometry' in data:
            from geometry_validation import validate
            try:geometry_json=validate(data['geometry'],n,edges,streets)
            except (ValueError,TypeError,ZeroDivisionError,OverflowError) as e:raise Error(str(e))
        with self.lock:
            self.current+=1
            snap=Snapshot(self.current,n,tuple(sorted(edges)),tuple(streets),geometry_json)
            self.history[snap.version]=snap
            if len(self.history)>32: del self.history[min(self.history)]
            return snap
    def get(self, version=None):
        with self.lock:
            if version is not None: integer(version,1,2**53)
            snap=self.history.get(self.current if version is None else version)
            if snap is None: raise Error('Graph version not found or expired',404)
            return snap

class Engine:
    def __init__(self, executable=None, timeout=3):
        self.timeout=timeout
        self.executable=str(executable or ROOT/'engine'/'graph_engine')
        self.slots=threading.BoundedSemaphore(4)
    def execute(self,snap,args):
        if not isinstance(args,dict):raise Error('Tool arguments must be an object')
        if set(args)-{'source','target','operation','avoid_nodes','avoid_edges','avoid_streets'}:raise Error('Unknown tool arguments')
        catalog={name.casefold():(name,edges) for name,edges in snap.streets}
        def street(value):
            if not isinstance(value,str) or value.strip().casefold() not in catalog:raise Error('Unknown street: '+str(value))
            return catalog[value.strip().casefold()]
        excluded=args.get('avoid_streets',[])
        if not isinstance(excluded,list):raise Error('avoid_streets must be an array')
        extra=[]
        for name in excluded:extra.extend(street(name)[1])
        clean=dict(args);clean.pop('avoid_streets',None)
        if not isinstance(clean.get('avoid_edges',[]),list):raise Error('avoid_edges must be an array')
        clean['avoid_edges']=clean.get('avoid_edges',[])+[list(e) for e in extra]
        named=any(isinstance(args.get(k),str) for k in ['source','target'])
        if not named:return self._execute_graph(snap,clean)
        blocked=args.get('avoid_nodes',[])
        if not isinstance(blocked,list):raise Error('avoid_nodes must be an array')
        blocked={integer(v,1,snap.n) for v in blocked}
        sets=[]
        for key in ['source','target']:
            value=args.get(key)
            if isinstance(value,str):
                name,edges=street(value);vertices={v for edge in edges for v in edge}
                if not vertices:raise Error('Street has no routable nodes: '+name)
            else:vertices={integer(value,1,snap.n)}
            vertices-=blocked
            if not vertices:raise Error('All endpoint nodes are excluded')
            sets.append(vertices)
        for pair in clean['avoid_edges']:
            if not isinstance(pair,(list,tuple)) or len(pair)!=2:raise Error('Invalid avoided edge')
            for v in pair:integer(v,1,snap.n)
        # Two virtual endpoints make set-to-set routing a single deterministic BFS.
        extra_edges=[tuple(sorted((v,snap.n+i+1))) for i,vertices in enumerate(sets) for v in vertices]
        augmented=Snapshot(snap.version,snap.n+2,tuple(sorted(snap.edges+tuple(extra_edges))))
        clean.update(source=snap.n+1,target=snap.n+2)
        result=self._execute_graph(augmented,clean)
        if result['path']:result['path']=result['path'][1:-1];result['hops']=len(result['path'])-1
        result['endpoints']={'source':args['source'],'target':args['target']}
        result['street_semantics']='Minimum hops between any nodes on the named streets; shared intersection may be 0 hops. Avoided streets block edges, not intersection nodes.'
        return result
    def _execute_graph(self,snap,args):
        if not isinstance(args,dict): raise Error('Tool arguments must be an object')
        allowed={'source','target','avoid_nodes','avoid_edges','operation'}
        if set(args)-allowed: raise Error('Unknown tool arguments')
        s=integer(args.get('source'),1,snap.n); t=integer(args.get('target'),1,snap.n)
        op=args.get('operation','shortest_path')
        if op not in ('shortest_path','reachable'): raise Error('Unsupported operation')
        nodes=args.get('avoid_nodes',[]); edges=args.get('avoid_edges',[])
        if not isinstance(nodes,list) or not isinstance(edges,list): raise Error('Avoid constraints must be arrays')
        blocked={integer(v,1,snap.n) for v in nodes}; blocked_edges=set()
        for e in edges:
            if not isinstance(e,list) or len(e)!=2: raise Error('Invalid avoided edge')
            blocked_edges.add(tuple(sorted(integer(v,1,snap.n) for v in e)))
        if s in blocked or t in blocked: raise Error('Source or target is excluded')
        filtered=[e for e in snap.edges if not blocked.intersection(e) and e not in blocked_edges]
        started=time.perf_counter()
        if not self.slots.acquire(timeout=.25): raise Error('Engine busy; retry later',503,'worker_busy')
        queue_ms=(time.perf_counter()-started)*1000
        try:
            payload=f'{snap.n} {len(filtered)} {s} {t}\n'+''.join(f'{a} {b}\n' for a,b in filtered)
            worker_start=time.perf_counter()
            run=subprocess.run([self.executable],input=payload,text=True,capture_output=True,timeout=self.timeout)
            if run.returncode: raise Error('Graph worker failed',502,'worker_exit')
            output=run.stdout.strip()
            path=[] if output=='NONE' else [int(x) for x in output.split()]
            if output!='NONE':
                legal=set(filtered)
                if not path or path[0]!=s or path[-1]!=t or any(tuple(sorted(e)) not in legal for e in zip(path,path[1:])):
                    raise Error('Invalid worker output',502,'worker_invalid_output')
            compute=None
            if run.stderr.startswith('compute_ms '):
                try:compute=float(run.stderr.split()[1])
                except (ValueError,IndexError):pass
            return {'graph_compute_ms':compute,'graph_version':snap.version,'operation':op,'reachable':bool(path),'path':path,
                    'hops':len(path)-1 if path else None,'queue_ms':round(queue_ms,3),
                    'worker_ms':round((time.perf_counter()-worker_start)*1000,3),'engine_ms':round((time.perf_counter()-started)*1000,3)}
        except subprocess.TimeoutExpired: raise Error('Graph worker timed out',504,'worker_timeout')
        except (OSError,ValueError): raise Error('Graph worker unavailable or malformed output',502,'worker_unavailable')
        finally: self.slots.release()
