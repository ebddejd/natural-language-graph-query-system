"""Local fault drills. No real model or credentials; no production fault endpoint."""
import contextlib,io,json,os,sys,tempfile,time,threading
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from unittest.mock import patch
from app import Service
from core import Engine,Error,ROOT
import model_config

def run():
    results=[];s=Service(active=1,waiting=1,queue_timeout=.02)
    def check(name,action,expected):
        try:action();raise AssertionError('Expected failure did not occur')
        except Error as e:
            assert e.code==expected,(name,e.code)
            r=s.query({'mode':'structured','arguments':{'source':1,'target':6}})
            assert r['reachable'] and s.admission.state()['active']==0
            results.append({'scenario':name,'error_code':e.code,'http_status':e.status,'recovery':'passed'})
    with tempfile.TemporaryDirectory() as d:
        def worker(name,code):
            p=Path(d)/name;p.write_text('#!'+sys.executable+'\n'+code);p.chmod(0o700);return str(p)
        good=s.engine
        for name,code,expected in [('worker_exit','raise SystemExit(7)','worker_exit'),('worker_hang','import time;time.sleep(2)','worker_timeout')]:
            bad=Engine(worker(name,code),timeout=3 if name=='worker_exit' else .05)
            def action():
                s.engine=bad
                try:s.query({'mode':'structured','arguments':{'source':1,'target':6}})
                finally:s.engine=good
            check(name,action,expected)
    before=s.store.get()
    check('incomplete_graph_update',lambda:s.store.publish({'nodes':8,'edges':[[1,2],[2]]}),'invalid_request')
    assert s.store.get()==before
    class SlowModel(BaseHTTPRequestHandler):
        calls=0
        def do_POST(self):
            SlowModel.calls+=1
            self.rfile.read(int(self.headers['Content-Length']))
            if SlowModel.calls==1:time.sleep(.15)
            try:self.send_response(200);self.end_headers();self.wfile.write(json.dumps({'choices':[{'message':{'tool_calls':[{'function':{'name':'query_graph','arguments':json.dumps({'source':1,'target':6})}}]}}]}).encode())
            except OSError:pass
        def log_message(self,*a):pass
    server=ThreadingHTTPServer(('127.0.0.1',0),SlowModel);t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
    try:
        with patch.object(model_config,'_settings',{'base_url':f'http://127.0.0.1:{server.server_port}/v1','model':'fake','api_key':'local-test'}),patch.dict(os.environ,{'LLM_TIMEOUT_SECONDS':'.03'}):
            check('model_transport_timeout',lambda:s.query({'mode':'llm','text':'from 1 to 6'}),'model_timeout')
            assert s.query({'mode':'llm','text':'from 1 to 6'})['reachable']
    finally:server.shutdown();server.server_close();t.join()
    s.admission.enter()
    try:
        try:s.query({'mode':'structured','arguments':{'source':1,'target':6}})
        except Error as e:assert e.code=='queue_timeout'
        else:raise AssertionError('Queue timeout not triggered')
    finally:s.admission.leave()
    assert s.query({'mode':'structured','arguments':{'source':1,'target':6}})['reachable']
    results.append({'scenario':'queue_timeout','error_code':'queue_timeout','http_status':504,'recovery':'passed'})
    return {'scope':'Local real subprocess exit/timeout and local HTTP model stall; no external API calls. Invalid graph publication preserves prior snapshot.','passed':len(results),'scenarios':results,'metrics':s.metrics.snapshot()}
if __name__=='__main__':
    with contextlib.redirect_stdout(io.StringIO()):report=run()
    (ROOT/'reports/faults.json').write_text(json.dumps(report,indent=2));print(json.dumps({'passed':report['passed'],'scenarios':report['scenarios']},indent=2))
