"""Process-local configuration. Secrets never returned or written to disk."""
import os,threading
from contextvars import ContextVar
visitor_settings=ContextVar("visitor_settings",default=None)
from urllib.parse import urlsplit
from core import Error
_lock=threading.Lock();_settings=None

def validate_url(base):
    if not isinstance(base,str):raise Error('API URL must be text')
    p=urlsplit(base)
    if p.username or p.password or p.query or p.fragment or not p.hostname:raise Error('Invalid API base URL')
    if p.scheme!='https' and not (p.scheme=='http' and p.hostname in ('localhost','127.0.0.1','::1')):raise Error('Use HTTPS, or HTTP for a local model')
    return base.rstrip('/')

def current():
    visitor=visitor_settings.get()
    if visitor is not None:
        return dict(visitor.get("settings", {"base_url":"https://api.openai.com/v1","model":"","api_key":""}))
    with _lock:
        if _settings is not None:return dict(_settings)
    return {'base_url':os.getenv('LLM_BASE_URL','https://api.openai.com/v1'),'model':os.getenv('LLM_MODEL',''),'api_key':os.getenv('LLM_API_KEY','')}

def public():
    c=current();local=urlsplit(c['base_url']).hostname in ('localhost','127.0.0.1','::1')
    return {'base_url':c['base_url'],'model':c['model'],'has_key':bool(c['api_key']),'configured':bool(c['model'] and (c['api_key'] or local))}

def configure(body):
    global _settings
    if not isinstance(body,dict):raise Error('Expected settings object')
    base=validate_url(body.get('base_url',''));model=body.get('model');key=body.get('api_key','')
    if not isinstance(model,str) or not model.strip() or len(model)>200:raise Error('Enter a model name')
    if not isinstance(key,str) or len(key)>4096 or '\n' in key or '\r' in key:raise Error('Invalid API key')
    previous=current()
    if not key and previous['base_url']==base and previous['model']==model.strip():key=previous['api_key']
    if not key and urlsplit(base).hostname not in ('localhost','127.0.0.1','::1'):raise Error('Enter an API key for the cloud provider')
    settings={'base_url':base,'model':model.strip(),'api_key':key.strip()}
    visitor=visitor_settings.get()
    if visitor is not None:visitor['settings']=settings
    else:
        with _lock:_settings=settings
    return public()
