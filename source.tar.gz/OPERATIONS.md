# Service engineering guide

## Run and inspect

```sh
make run
make test
make faults
make bench
```

`GET /api/metrics` and the page's 服务运行指标 panel expose current queue occupancy, lifetime counters, and P50/P95 over the last 2,000 completed query attempts. Refreshing metrics does not call a model. Logs go to stdout as structured JSON for every query success/error, with request ID, graph version, mode, status, error code and measured stages. Prompts, secrets, provider error bodies and street names are excluded. Error responses include request IDs; 503 responses from the application include Retry-After.

## Bounds

- HTTP: 48 handler threads maximum. Excess connections receive 503 before a thread is allocated. Socket inactivity timeout is 10 seconds. HTTP-level rejected connections are not query attempts and are outside query metrics.
- Query admission: 4 active requests, 16 FIFO waiting positions, 2-second queue wait timeout. A full queue returns `queue_full` (503); a wait timeout returns `queue_timeout` (504).
- Graph snapshots are pinned before admission/model execution. Waiting requests continue using their selected version.
- C++: 4 slots, 250 ms slot wait, 3-second subprocess timeout. Timed-out subprocesses are killed and reaped by subprocess.run. The next request uses a new worker process.
- Provider: 45-second network timeout by default, configurable via LLM_TIMEOUT_SECONDS. This is a socket-operation timeout, not a strict end-to-end deadline against a trickling peer. No automatic model retries or hidden extra charges.
- Queued requests release capacity on errors. A client disconnect does not immediately cancel model execution; bounded slots remain held until completion or timeout. This is a local development service, not a distributed production ingress.

## Timing definitions

| Field | Meaning |
|---|---|
| admission_ms | FIFO request admission wait |
| planning_ms | parser or tool-call planning stage |
| model_ms | LLM planning only, including provider roundtrip and validation |
| worker_queue_ms | worker slot wait |
| worker_ms | subprocess launch, stdin/stdout and worker work |
| graph_compute_ms | C++ shortest-path computation only, measured inside worker |
| engine_total_ms | graph argument validation, filtering, worker wait and execution |
| total_ms | entire service query attempt, excluding HTTP parsing/transport |

These are nested timings; do not sum every column. Missing stages are absent rather than fabricated as zero. Metrics distinguish model/demo/structured modes and successful/failed attempts. Snapshot data is in memory and counters reset on restart.

## Fault drills

`python3 faults.py` writes `reports/faults.json`. It runs in an isolated process using temporary executable workers and a localhost fake model, never the configured cloud provider. Scenarios:

1. Actual worker exits with nonzero code → 502; healthy worker serves next request.
2. Actual worker sleeps past deadline → 504; worker is reaped and capacity recovered.
3. Partially formed graph update → 400; prior complete snapshot unchanged and queryable.
4. Local HTTP model stalls → model_timeout 504; subsequent structured query and subsequent HTTP model tool call both succeed.
5. Admission wait exceeds timeout → 504; later request succeeds.

FIFO order, full queue rejection, HTTP capacity rejection/recovery, bounded metric storage and log redaction are also covered by unit/integration tests. Fault controls are not exposed through the public HTTP API.

## Performance experiment

`python3 benchmark.py --requests 100` runs concurrency 1/4/8/16/32 for both structured queries and a fixed 30 ms simulated model. Reports contain successful throughput, successful P95, all-outcome P95, rejection counts and stage P95. `reports/concurrency.json` is the measured output. It uses real C++ workers but excludes HTTP transport; simulated model timings are NOT live provider performance. Under overload, quick rejection can lower all-outcome P95; compare successful latency and rejection counts together. Re-run on the same machine for comparisons.

## Resume-safe scope

A local AI application service with named-street tool calling, immutable graph snapshots, bounded admission, structured observability, reproducible load tests and recovery drills. This does not demonstrate distributed deployment, GPU serving or model training. Live natural-language quality and external-provider latency require a separately authorized evaluation with actual credentials.
