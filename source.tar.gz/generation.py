"""One-shot A3 random streets -> intersection graph, isolated from original files."""
import json, re, subprocess, sys, threading
from core import ROOT, Error, integer
_slots=threading.BoundedSemaphore(2)
def generate(body):
    if not isinstance(body,dict):raise Error('Expected generation settings object')
    streets=integer(body.get('streets',6),2,12)
    segments=integer(body.get('segments',2),1,4)
    coord=integer(body.get('coord',20),5,100)
    if not _slots.acquire(blocking=False):raise Error('Graph generator busy; retry shortly',503)
    try:
        for _ in range(4):
            r=subprocess.run([str(ROOT/'generator/rgen'),'-s',str(streets),'-n',str(segments),'-c',str(coord)],capture_output=True,text=True,timeout=3)
            if r.returncode:continue
            g=subprocess.run([sys.executable,str(ROOT/'generator/export_graph.py')],input=r.stdout,capture_output=True,text=True,timeout=5)
            if g.returncode or g.stderr:continue
            graph=json.loads(g.stdout)
            if graph['nodes'] and graph['edges']:
                names=['King Street','University Avenue','Columbia Street','Weber Street','Albert Street','Waterloo Road','Cedar Street','Maple Avenue','Queen Street','Victoria Street','Bridge Street','Park Avenue']
                mapping={old:names[i] for i,old in enumerate(graph['streets'])}
                graph['streets']={mapping[old]:edges for old,edges in graph['streets'].items()}
                graph['geometry']['roads']={mapping[old]:points for old,points in graph['geometry']['roads'].items()}
                return graph
        raise Error('No intersecting street graph generated. Please try again.',503)
    except subprocess.TimeoutExpired:raise Error('Graph generation timed out. Try fewer streets or segments.',504)
    except OSError:raise Error('Generator unavailable. Run make and restart the server.',503)
    finally:_slots.release()
