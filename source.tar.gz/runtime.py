"""Bounded FIFO admission and bounded, low-cardinality metrics."""
import threading,time,math
from collections import deque,Counter
from core import Error

def percentile(values,p):
    if not values:return None
    values=sorted(values);return round(values[max(0,math.ceil(len(values)*p)-1)],3)

class Admission:
    def __init__(self,active=4,waiting=16,timeout=2):
        self.limit=active;self.capacity=waiting;self.timeout=timeout
        self.active=0;self.waiters=deque();self.cv=threading.Condition()
    def enter(self):
        start=time.perf_counter();ticket=object()
        with self.cv:
            if self.active<self.limit and not self.waiters:self.active+=1;return 0.0
            if len(self.waiters)>=self.capacity:raise Error('Request queue full; retry later',503,'queue_full')
            self.waiters.append(ticket)
            while True:
                remaining=self.timeout-(time.perf_counter()-start)
                if remaining<=0:
                    self.waiters.remove(ticket);self.cv.notify_all();raise Error('Request queue wait timed out',504,'queue_timeout')
                if self.waiters[0] is ticket and self.active<self.limit:
                    self.waiters.popleft();self.active+=1;self.cv.notify_all();return (time.perf_counter()-start)*1000
                self.cv.wait(remaining)
    def leave(self):
        with self.cv:self.active-=1;self.cv.notify_all()
    def state(self):
        with self.cv:return {'active':self.active,'waiting':len(self.waiters),'active_limit':self.limit,'queue_capacity':self.capacity,'queue_timeout_seconds':self.timeout}

class Metrics:
    def __init__(self,window=2000):
        self.lock=threading.Lock();self.rows=deque(maxlen=window);self.counts=Counter();self.started=time.time();self.window=window
    def record(self,row):
        with self.lock:
            self.rows.append(dict(row));self.counts['requests']+=1;self.counts['status_'+str(row['http_status'])]+=1
            if row.get('error_code'):self.counts[row['error_code']]+=1
    def snapshot(self):
        with self.lock:rows=list(self.rows);counts=dict(self.counts)
        groups={}
        for mode in ['llm','demo','structured','unknown']:
            subset=[r for r in rows if r['mode']==mode]
            if not subset:continue
            groups[mode]={}
            for outcome,chosen in [('success',[r for r in subset if r['http_status']<400]),('error',[r for r in subset if r['http_status']>=400])]:
                groups[mode][outcome]={'count':len(chosen),'stages':{k:{'samples':sum(k in r for r in chosen),'p50_ms':percentile([r[k] for r in chosen if k in r],.5),'p95_ms':percentile([r[k] for r in chosen if k in r],.95)} for k in ['total_ms','admission_ms','planning_ms','model_ms','worker_queue_ms','worker_ms','graph_compute_ms','engine_total_ms']}}
        return {'uptime_seconds':round(time.time()-self.started,1),'counters_since_start':counts,'rolling_window_capacity':self.window,'rolling_samples':len(rows),'by_mode':groups,'recent':rows[-20:]}
